# Task 3 independent review

Spec compliance verdict: **PASS for the scoped implementation**.

Code quality verdict: **PASS**. **No P1/P2 blockers found.** Rendered accessibility and responsive acceptance still require the coordinator's browser evidence; this review does not substitute for it.

## Scope

Reviewed task-3-brief.md, task-3-report.md, the change's design/tasks/plan and wzap-manager delta spec, and Task 3 hunks in final-review-package.md. The package's dirty snapshot is the baseline. Used the installed-library theme and labels inspection briefs, with targeted source confirmation. No HEAD-versus-working-tree review, browser, source changes, child agents, commits or dependencies.

## Findings and evidence

- `manager/app/assets/css/main.css:20` scopes the five darker semantic aliases to light mode. It retains the existing palette and does not override the dark root aliases. This addresses current primary actions/active navigation and success/info/warning/error feedback together.
- `manager/app/app.config.ts:8` adds exactly three button compound variants through the supported Nuxt UI configuration. The installed-library brief confirms these append to the generated compounds and resolve through tailwind-merge rather than replacing the theme. Primary light hover/active uses shade 900 while explicitly retaining the dark 75% variant (`:12`). Error dark solid hover/active increases to 90% (`:17`); error dark soft hover/active stays at 10% (`:22`) to avoid the existing nested retry contrast failure. These are narrow current-state corrections; dark semantic aliases remain unchanged.
- The brief's **predicted, not browser-tested** ratios support the selected shades: light primary solid 7.19 at rest / 9.15 on hover; subtle-card feedback descriptions at least 4.64 among the selected aliases; light nested error retry hover approximately 5.06 on a subtle card. Existing dark primary hover predicts at least 5.94; corrected dark error solid hover at least 5.18, and current default-surface nested error retry 4.66. No requirement for unused future variants is inferred. Final rendered measurements remain necessary, including the actual alert backgrounds and description opacity.
- `manager/app/components/instances/detail/InstanceSectionNav.vue:8` is one explicit list of all seven translated choices. Desktop `active` and `onSelect` derive from the same list at `:20`. Mobile receives the plain list and uses only model-update emission at `:35`, avoiding the installed Select's additional item `onSelect` callback path. Both controls receive current section state.
- The mobile trigger is named at `InstanceSectionNav.vue:32`, fills available width, and has an explicit 44px minimum at `:34`. Its switch at `lg` matches the existing dashboard breakpoint. Full labels are retained as choice data; actual 320/390px fitting, popup behavior and overflow are browser acceptance checks.
- `manager/app/pages/instances/[id].vue:128` supplies the localized back-action name without changing its destination. Locale entries exist at `manager/i18n/locales/en.json:190` and `:349`.
- Existing URL semantics are preserved: `[id].vue:35` validates query sections, `:42` uses replace while preserving other query fields and removes the overview section parameter, and `:50` responds to external query changes. The nav still feeds that state via `:140`. Existing instance identity, stale-response and rename handling at `:61`–`:104` was not modified by these QA deltas.

## Test quality and independent verification

`manager/app/components/instances/detail/InstanceSectionNav.test.ts:27` compiles the actual SFC and exercises its model-update event across seven choices, externally changed current selections at `:48`, and desktop callbacks at `:66`. It does not duplicate a navigation implementation or assert CSS constants. The primitives are substituted, so the “once” check verifies one emitted event per invoked model update; the absence of item callbacks in the real mobile data and installed Select source establish why real selection has a single emission path. Actual keyboard selection remains browser-owned.

Ran:

```sh
pnpm --config.verify-deps-before-run=false --dir manager test app/components/instances/detail/InstanceSectionNav.test.ts app/pages/instances/detail.test.ts
```

Exit **0**: **2 files, 8 tests passed**. Only the existing Vue Suspense informational message appeared. The five existing detail tests cover retained UUID/alias navigation and stale-instance protection, including rename query/hash preservation. No full gates were repeated; those and mandatory visual checks remain with the coordinator.

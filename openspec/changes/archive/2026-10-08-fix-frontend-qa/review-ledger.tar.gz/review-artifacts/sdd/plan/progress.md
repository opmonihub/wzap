# SDD ledger — plan: openspec/changes/fix-frontend-qa/plan.md

Baseline HEAD f9d1300; source snapshot contains the existing uncommitted manager fixes. No commits requested. Task reviews compare against /tmp/wzap-frontend-fix-baseline, not HEAD.

| Tasks/interface | Produces / consumes | Result |
|---|---|---|
| 1 / self | Parser accepts the actual numeric UI model; tests exercise same schema and submit path | consistent |
| 2 / self | Distinct checkbox target and named primitive roots; browser proves actual forwarding | consistent |
| 3 / self | CSS aliases and selected section control; rendered browser verifies contrast/navigation | consistent |
| 1, 2, 3 / locale | Implementers request keys; controller is sole locale writer | consistent |
| 1, 2, 3 / manager generated files | Focused Vitest only; final prepare/typecheck/build after writers | consistent |
| 2, 3 / instance detail | Task 2 owns settings child; Task 3 owns page/nav | disjoint |
| 4 / self | Fresh complete manager gates after three scopes | consistent |
| 5 / self | Independent review and updated-build browser QA | consistent |
| 6 / self | Hash-guarded apply and cleanup only owned fixtures | consistent |
| 4, 5 / build | Build output copied to QA static root after gates | ordered |
| 5, 6 / evidence | Report/gates precede guarded apply and final records | ordered |

Browser RED baseline: report.md findings ISSUE-001..007 and before screenshots; form logic adds automated RED evidence before edits. No unresolved plan conflicts.

Task 1: implementation/review complete (dirty-baseline diff; review clean; 57 focused tests GREEN independently). Browser acceptance and full gates pending before task 1.1 checkbox.

Additional confirmed general-QA ISSUE-008: Display menu empty because required instance columns all have enableHiding:false. Tasks/spec/plan extended with 1.4; minimal shared-toolbar conditional preserves Accounts options and required identity/status. No conflicting task writer/interface.

Task 2: implementation/review complete (dirty-baseline diff; spec+quality PASS; 38 focused tests GREEN). Browser 1.2/1.4 acceptance pending.

Task 3: implementation/review complete (spec+quality PASS; 8 focused tests GREEN). Whole 22-file review PASS with no P1/P2 blockers. Full Vitest 110/110, Node7/7, lint0errors2existingwarnings, typecheck0; build and browser pending.

### Task 2: Núcleo, segurança e import (tasks 2.1–2.5, 2.7–2.8, 2.10–2.11)

**Ownership:** internal/instance, internal/session, internal/webhook, internal/chatwoot/** e teste de sealing em internal/storage/postgres/chatwoot_test.go; cmd/wzap/main.go somente se necessário habilitar history-sync/lifecycle, com aviso ao coordenador; não editar httpapi/manager ou outros arquivos storage/message/events.
**Files:** instance/service.go e regressões; session/whatsmeow/manager.go e testes de restore/device bind; webhook/{deliver,ssrf}.go e testes; chatwoot/client/client.go e client_test.go; chatwoot/config/token.go e token_test.go; storage/postgres/chatwoot_test.go.
**Interfaces:** Service.Update mantém UpdateInput de ponteiros; locker próprio por instância; SealToken/OpenToken recebem/retornam plaintext na fronteira de repositório.

- [ ] Ler probes originais `/tmp/wzap-core-review-probes/overlay.json` para reutilizar evidência sem refazer descoberta.
- [ ] RED 2.1: duas calls reais Service.Update com barreiras demonstram webhook-only/partial identity reverting rename e partial webhook reverting enabled/events.
- [ ] GREEN 2.1: adquirir locker antes de Get, manter até escrita; não UpdateIdentity quando campos de identidade ausentes; testar cancelamento/erros e não reentrância.
- [ ] RED 2.2: bound JID sintético inválido/ausente/mismatch/upstream error não aparece em log nem reason/projeção; errors.Is de sentinels/contexto permanece útil.
- [ ] GREEN 2.2: retirar JID na origem e impedir propagar detalhes sensíveis do upstream em reason, manter IDs opacos/categoria segura.
- [ ] RED 2.3: dois httptest origins com redirect 307 e downgrade HTTPS->HTTP; destino secundário não é chamado e 3xx é erro.
- [ ] GREEN 2.3: no redirect nos dois clientes autenticados e fechamento/tratamento correto do response.
- [ ] RED 2.4: plaintext `enc:v1:...` passa round trip e nunca fica intacto no SQL; Get->Put sempre sela; empty/tamper/wrong-key continuam cobertos.
- [ ] GREEN 2.4: selar toda entrada não vazia, sem heurística de prefixo.
- [ ] RED 2.5: data_url de outro host com `[loopback, IP público confiável]` não alcança servidor loopback; testar redirects e todos os endereços usados no dial, além de host privado Chatwoot legítimo.
- [ ] GREEN 2.5: exceção apenas para identidade confiável completa, sem sobreposição parcial de DNS.
- [ ] RED 2.7: chunk inserido entre snapshot e conclusão continua pendente; import com erro conserva lote original e chunks novos.
- [ ] GREEN 2.7: acrescentar reconhecimento do lote ao HistoryFeed/Accumulator e fakes, sem reset integral que apague dados recebidos depois.
- [ ] RED 2.8: import URI ausente não retém chunks/contacts/conversations nem dispara previews/completion; habilitado continua acumulando.
- [ ] GREEN 2.8: habilitação explícita da coleta no manager/session e fixtures claras para habilitado/desabilitado.
- [ ] RED 2.10: contains retorna telefone alheio mais longo e exato BR; somente variantes exatas são selecionadas/fundidas; grupos/fallback exigem identifier exato.
- [ ] GREEN 2.10: filtrar resultados antes de longest/merge e não criar correlação com contato alheio.
- [ ] RED 2.11: instance criada sem sessão + init cria/inicia sessão e QR; init:number usa lifecycle/pareamento; status confirma nome/estado sem JID.
- [ ] GREEN 2.11: reutilizar lifecycle do serviço, com fakes de contrato atualizados e nenhum novo mecanismo paralelo.
- [ ] Verificar focused Go nos pacotes e `go test -race ./internal/instance ./internal/session/whatsmeow ./internal/webhook ./internal/chatwoot/client ./internal/chatwoot/config -count=1`; DB focused quando configurado pelo coordenador.


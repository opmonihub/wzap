# Task 2 implementation report

Status: scoped implementation complete; coordinator browser validation and full gates pending.

## Changes and evidence

- `manager/app/components/instances/WebhookCard.vue:24,158`: one Vue `useId()` per mounted editor plus event type suffix provides unique checkbox IDs. Existing Nuxt UI checkbox label now targets its own checkbox; subscription logic, order, All/None, enabled and URL logic unchanged.
- FileUpload supported `label` prop now supplies visible descendant text for the actual role-button (external aria-label would reach only hidden native input in installed UI): ProfileCard.vue:135, GroupDetail.vue:312, ChannelsCard.vue:248, MessageComposer.vue:296, TestSendCard.vue:540. Uses existing profile/group photo and send file translations.
- Actual Select trigger names use forwarded aria-label: GroupDetail.vue:331 participants action, ChannelsCard.vue:243 status kind, detail/InstanceSettingsSection.vue:191 default disappearing timer. Existing locale keys only; no new keys.
- Scope addition ISSUE-008 / task 1.4: `manager/app/components/shared/DataTableToolbar.vue:42` renders column-display dropdown only when `columnItems.length > 0`. Required instance columns remain locked; Accounts optional columns keep the existing menu and handlers.
- `manager/app/components/instances/WebhookCard.test.ts`: two meaningful behavior tests exercise independent receipt/group.info subscriptions saved in contract order, All/removal/None, indeterminate removal, disabled webhook with empty URL/events. Tests use actual component handlers; no attribute-mirroring tests added.
- Existing snapshot changes and Task 1 form work preserved; no locale/page/nav/theme edits, dependencies, generated changes, browser sessions, primary-workspace writes or commits.

## Verification

- Final focused command: `pnpm --config.verify-deps-before-run=false --dir manager test app/components/instances/WebhookCard.test.ts app/components/instances/ProfileCard.test.ts app/components/instances/ChannelsCard.test.ts app/components/instances/MessageComposer.test.ts app/components/instances/detail/InstanceSettingsSection.test.ts` — exit 0, 5 files and 38 tests passed.
- Scoped ESLint from manager cwd across eight UI files plus new webhook test — exit 0, zero errors. One pre-existing warning `DataTableToolbar.vue:9 vue/no-required-prop-with-default`; left outside scoped conditional fix. Initial lint invoked from repository root selected incorrect configuration and reported parse errors; rerun from manager resolved those. Adding fourth inline attribute exceeded Vue attribute count, fixed by multiline markup before final passing lint.
- `git diff --check` — exit 0.
- Impeccable context read; scoped refine allowed without PRODUCT.md. Clarify reference and craft floor read before UI edits. Mechanical detector over original seven UI targets and separately added toolbar target both returned `[]`, exit 0.
- No Go source changes; gofmt not applicable.

## Browser handoff / limits

Pre-fix RED evidence remains primary `dogfood-output/frontend-2026-10-07/report.md` ISSUE-005/006 and `screenshots/30-instance-display-empty-menu.png` ISSUE-008. Tests deliberately use primitive stubs and cannot establish installed library forwarding, real label activation or accessible names.

Coordinator must verify real browser labels toggle receipt/group.info independently without message, save/reload subscriptions; all five picker role-button names and keyboard activation with empty/selected/removed file states; three Select names and changes; desktop/narrow layouts; Instances has no empty Display menu and Accounts retains optional-column toggling. Browser evidence is required before declaring overall UI complete. No known scoped implementation concern beyond that pending verification.

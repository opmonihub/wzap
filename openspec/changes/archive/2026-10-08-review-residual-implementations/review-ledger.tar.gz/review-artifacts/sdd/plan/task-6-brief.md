### Task 6: Isolamento de recibos e durabilidade terminal (tasks 2.6, 2.9)

**Ownership:** internal/message/**, internal/storage/repository.go, internal/storage/postgres/{messages,eventoutbox}*.go e testes correspondentes, internal/events/**; consumer fakes em outros pacotes somente coordenados com writer daquele pacote; não editar session/chatwoot/instance/httpapi simultaneamente.
**Files:** message/{receipts,outbox}.go e testes; storage/postgres/messages.go, outbox de eventos e teste transacional; interfaces consumer/storage necessárias; webhook fan-out e cmd wiring somente depois de Task 2 liberar esses arquivos.
**Interfaces:** UpdateReceipt recebe instanceID explícito antes de WhatsApp ID; confirmação terminal persiste state+outbox atomicamente no banco existente, sem novas tabelas/migrações e sem converter contrato REST/event v1.

- [ ] RED 2.6: reutilizar probe /tmp/wzap-core-review-wave2/overlay.json com DB _test/postgrestest; duas instâncias e mesmo wa_id alteram somente alvo do receipt.InstanceID; incluir mensagem ausente/sentinels.
- [ ] GREEN 2.6: atualizar interface/chamada/predicado SQL e fakes de contrato, mantendo eventos no subject da instância correta.
- [ ] RED 2.9: sent/failed não podem commit sem evento durável; simular falha de insert/commit real em schema isolado e comprovar rollback completo; retry de persistência mantém event_id e conta de envio WhatsApp em um.
- [ ] GREEN 2.9: transação única para update de mensagem+insert de evento; fan-out somente após commit e sem double-write/double-delivery; retry guarda resultado do envio e evento já construído, sem chamar o sender de novo.
- [ ] Verificar `go test ./internal/message ./internal/events ./internal/storage/postgres -count=1` com DB isolado para testes SQL; registrar duração e RED/GREEN em task-6-report.md; revisão cruzada após patch.

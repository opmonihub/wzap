## Task 7 / ISSUE-009: native instances-table row semantics

Implemented in the isolated `fix-frontend-qa` worktree. Only the assigned table component and approved focused helper/test changed.

### Evidence and solution

- Browser RED supplied by root: `after-instances-table-light-a11y.json` reports `nested-interactive` for both instance rows.
- Installed `manager/node_modules/@nuxt/ui/dist/runtime/components/Table.vue:321` and `:322` add `role="button"` and `tabindex="0"` when `onSelect` exists; rows already contain links, checkboxes and buttons. The table does not offer a row-attributes callback.
- The installed component exposes `tableRef`/`tableApi` at `Table.vue:305` and forwards root attributes at `:490`. Its unpinned/nonvirtualized body follows `tableApi.getRowModel().rows` (`:224`, `:226`, `:428`).
- `manager/app/components/instances/InstancesTable.vue:214` now delegates root pointer clicks rather than configuring `onSelect`; template binding is at `:286`. The table therefore retains native row semantics. Native name links, selection checkboxes and action buttons remain keyboard targets.
- `manager/app/utils/tableRowNavigation.ts:2` resolves a click only when its native row belongs directly to the exposed table body and its closest table is the exposed table. It ignores interactive descendants, prevented/nonprimary clicks, header/outside rows, and empty-state rows. Body-row index maps into the current displayed model, preserving filtered/sorted/paginated identity.

### Tradeoff

The smallest supported change retains Nuxt UI rendering and existing row controls through exposed APIs and ordinary event delegation. DOM-role rewriting and observers were avoided. Pointer row navigation is an enhancement; keyboard users navigate through the existing name links. Row-index mapping intentionally matches the current table, which has no row expansion, pinning, body-slot insertions or virtualization. Adding those features would require reconsidering this mapping.

### Verification

- TDD RED: `pnpm --config.verify-deps-before-run=false --dir manager test app/utils/tableRowNavigation.test.ts` failed with two expected `undefined` versus displayed-row failures before implementation (sorted order and filtered page identity).
- Focused GREEN: the same command passed all 7 tests.
- Full manager suite: `pnpm --config.verify-deps-before-run=false --dir manager test` passed 14 files / 117 tests. Existing Vue Suspense experimental informational output appeared; no failures.
- Focused ESLint: `pnpm --config.verify-deps-before-run=false --dir manager exec eslint app/components/instances/InstancesTable.vue app/utils/tableRowNavigation.ts app/utils/tableRowNavigation.test.ts` exited 0 with no warnings after correcting template attribute order.
- `git diff --check` clean.
- Impeccable detector on the changed table: `[]` findings.
- Browser GREEN, full lint/typecheck/build and independent review remain with root as explicitly assigned. No browser claims made here, no dependencies/generated artifacts/commits, and no primary-worktree writes.

### Mutation assessment

Indexing loaded items rather than current displayed rows breaks the sorted/page identity cases. Removing interactive/ownership/header guards allows corresponding forbidden clicks to resolve; removing prevented/nonprimary guards breaks those cases. Tests exercise the actual resolver with minimal native DOM lookup boundaries; they do not assert framework role strings. Real browser QA remains necessary to validate the native selector matching and keyboard behavior.

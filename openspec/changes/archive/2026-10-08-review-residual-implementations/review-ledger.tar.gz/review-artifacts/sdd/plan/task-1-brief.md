### Task 1: API e autenticação (tasks 1.1–1.6)

**Ownership:** `internal/httpapi/**` e testes HTTP compartilhados; nenhum outro implementer escreve nessa árvore.
**Files:** core/{middleware,idempotency,instances}.go, composition wiring que chama Authenticate, authsession/login_ratelimit.go, messages/messages.go, statuses/status.go e testes correspondentes; pode adicionar regressões em arquivo dedicado no mesmo pacote.
**Interfaces:** consumir UserRepository existente; preservar assinatura pública REST e context Scope/TargetInstance; internal Authenticate pode receber repositório de usuários.

- [ ] RED 1.1: login real -> remoção da conta -> GET/POST admin dá 401; token admin com role atual user dá 403; falha de lookup falha fechado; API key funciona independente. Reusar fakeUserRepository/auth test, sem JWT sem conta real na fixture válida.
- [ ] GREEN 1.1: revalidar cookie antes de autorizar e atualizar role do scope; executar regressões.
- [ ] RED 1.2: router PUT timer e PATCH group settings executam setter uma vez no replay, 422 divergente/409 em progresso; canal/grupo distinto com mesma chave/body é 422; UUID/nome/rename preservam replay e autorização.
- [ ] GREEN 1.2: métodos registrados e fingerprint que conserva parâmetros além da referência da instância; manter hashes de rotas não afetadas quando viável.
- [ ] RED 1.3: mudar o teste que exige passthrough corrupto para exigir 500, zero calls e zero release; incluir status zero/inválido, JSON vazio/truncado/sem envelope e erro malformado; bytes íntegros continuam iguais.
- [ ] GREEN 1.3: validação mínima da integridade atual, sem DTO-conversão nem recarregar recurso.
- [ ] RED 1.4: JSON seguido de segundo valor/junk -> 400; JSON curto + espaços acima de 1 MiB -> 413; desconhecidos e whitespace final pequeno aceitos; zero efeito para os inválidos.
- [ ] GREEN 1.4: um Decode adicional exige EOF e respeita MaxBytesReader; confirmar erro de tamanho antes de qualquer efeito.
- [ ] RED 1.5: multipart com query concorrente não altera campo do form; inverter campos escalares repetidos muda o alvo efetivo e não pode replayar; incluir arquivo único/duplicatas relevantes.
- [ ] GREEN 1.5: campos vêm exclusivamente de multipart e fingerprint inclui sua semântica efetiva; preservar casos válidos existentes.
- [ ] RED 1.6: MaxLoginBuckets+1 IPs não aumenta mapa além do teto nem renova budget de IP conhecido; expiração libera capacidade usando relógio existente.
- [ ] GREEN 1.6: recusar overflow após limpeza de expirados, sem expulsar budgets ativos.
- [ ] Verificar: `go test ./internal/httpapi/... ./internal/auth/... -count=1`; registrar RED/GREEN por task em relatório próprio.


# Task 8 / ISSUE-010 implementation report

Status: scoped implementation complete; browser GREEN and final gates remain coordinator-owned.

## Root cause and API evidence

- Installed Nuxt UI `manager/node_modules/@nuxt/ui/dist/runtime/components/FileUpload.vue:159–168` default `file-leading` renders UAvatar with blob URL, file-icon fallback, size and styling but no alt prop. Native img selected through `{ img: 'img' }` therefore has no alt attribute.
- Installed `Avatar.vue:73–83` forwards `props.alt` directly to the selected image component; its img receives that alt verbatim. `Avatar.vue:86–89` retains icon fallback on load failure. Root class takes props.class at `Avatar.vue:49`, preserving caller slot classes.
- Installed `FileUpload.vue.d.ts:149–153` explicitly exposes `file-leading` slot with file, index and ui. FileUpload.vue:172–175 adjacent `fileName` continues to render the selected file name. File removal and hidden input are outside this slot and untouched.
- Existing VueUse `manager/node_modules/@vueuse/core/dist/index.js:5602–5613` useObjectUrl watches the source, revokes previous URL before replacement, and revokes the final URL on scope disposal.
- Nuxt generated theme defaults are md for both FileUpload and Avatar (`manager/.nuxt/ui/file-upload.ts:285–289`, `manager/.nuxt/ui/avatar.ts:98–100`). Current five callers have no size overrides; their preview retains the same default avatar size and slot class, including area/grid sizing.

## Implementation

- New `manager/app/components/shared/FileUploadPreview.vue:2–18` uses installed useObjectUrl with reactive file getter, native img UAvatar, `:alt="file.name"`, existing appConfig.ui.icons.file fallback, and original fileLeadingAvatar data slot.
- Filename alt is intentional: independent review confirmed default grid styling hides fileWrapper and its filename from both sight and accessibility. The image therefore identifies the actual selected file independently while retaining existing grid styling. This identifies the selection rather than claiming to describe image contents.
- Five callers import shared preview and override only file-leading using provided ui.fileLeadingAvatar() for styling: ProfileCard.vue:142–144; GroupDetail.vue:320–322; ChannelsCard.vue:255–257; MessageComposer.vue:303–305; TestSendCard.vue:548–550.
- Accessible picker labels, existing filename/file-size markup, removal button, upload area, keyboard action, file model/change handlers and input untouched.
- No dependency, locale, app.config, stylesheet, nav, table, generated, docs or primary-workspace changes. No commits or browser sessions.
- Coordinator approved narrowly necessary harness follow-up: `manager/tests/componentHarness.ts:79` provides shared visual preview as primitive dependency, keeping explicit imports strict otherwise; lines 145–150 invoke file-leading only for selected modelValue and supply file/index/ui class callback. Other slot handling unchanged. This preserves behavior tests without asserting visual attributes in stubbed primitives.

## Verification

- `node_modules/.bin/eslint` from manager cwd on new shared preview, five callers and tests/componentHarness.ts: exit 0, no diagnostics.
- `node_modules/.bin/vue-tsc --noEmit --project .nuxt/tsconfig.app.json`: exit 0, no diagnostics. No generated changes required.
- `pnpm --config.verify-deps-before-run=false --dir manager test app/components/instances/ProfileCard.test.ts app/components/instances/ChannelsCard.test.ts app/components/instances/MessageComposer.test.ts`: exit 0, 3 files and 28 tests passed, including selected-profile-file handler path.
- `git diff --check`: exit 0.
- Impeccable mechanical detector across six production targets: `[]`, exit 0; craft floor reread before edits. No repeated context run.
- Initial edit command used manager-prefixed paths from manager cwd and failed before any edits; retried correct relative paths. No primary writes occurred.

Review correction verification: shared preview now binds `:alt="file.name"`; scoped ESLint rerun from manager cwd passed, and `git diff --check` passed. No redundant test added for the binding; prior type evidence covers typed File.name and coordinator repeats final gates. An initial root-cwd lint selected incompatible parsing despite explicit config, corrected by manager-cwd invocation.

## Browser handoff and tradeoffs

Browser RED: primary `dogfood-output/frontend-2026-10-07/after-profile-file-picker-a11y.json`, image-alt failure on blob img data-slot=image. Coordinator must verify selected image shows thumbnail with alt matching the selected filename and removal remains visible and usable, reselection/removal works, accessibility scan no longer flags image-alt across five pickers, and non-image upload icon fallback still renders.

Focused tests intentionally stub visual primitives and cannot establish actual UAvatar native img or preview styling. Independent review correction binds file.name because default grid preview hides the filename wrapper; decorative-alt rationale has been replaced. Shared preview currently matches default md sizing in all existing callers; future caller-specific fileUpload/Avatar sizes or fileImage/fileIcon overrides should be propagated if introduced. Existing error fallback behavior retained for non-image file blob URLs. Object URL cleanup improves library default createObjectUrl behavior without changing API.

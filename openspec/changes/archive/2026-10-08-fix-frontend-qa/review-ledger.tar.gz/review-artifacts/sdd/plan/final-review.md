# Independent final frontend QA review

Overall spec implementation verdict: **PASS**.

Overall code quality verdict: **PASS**. **No P1/P2 blockers found in the 22-file QA delta.** This is a source/test review verdict, not a declaration that the full frontend delivery or mandatory browser acceptance is complete.

## Scope and evidence

Reviewed all 22 files represented in final-review-package.md against the pre-QA dirty snapshot, the change's design/tasks/plan and wzap-manager delta spec, task-3-brief/report and independent task-1/task-2 reviews. Inspected real schemas/handlers, account composable, webhook tests, navigation tests/page and component harness, with targeted installed-library checks informed by /tmp/wzap-frontend-{theme,labels}-inspection.md. Earlier unrelated dirty work was not folded into this review.

### Forms and quota boundaries

- `manager/app/utils/accountQuota.ts:3` now handles the actual number/string/undefined model; blanks and whitespace remain undefined, zero remains zero, and negative/fractional/NaN/infinite/invalid-text input is rejected by the integer/nonnegative checks. The change does not introduce truthiness coercion or convert blank input to unlimited.
- Creation schema `manager/app/components/accounts/CreateAccountModal.vue:21` accepts that input shape and rejects parser nulls. The existing handler normalizes at `:58`, and the actual `useAccounts.ts:27` includes `instance_limit` only when it is not undefined. Editing at `EditQuotaModal.vue:21` additionally rejects absent values, with a matching handler guard at `:45`. This preserves the distinction between default creation quota and required explicit edits.
- Numeric text continues to use the pre-existing Number conversion semantics; no new numeric range or lexical restriction was added. The tested supported values and invalid cases match this change's scope; backend range enforcement is not redefined here.
- `manager/app/components/auth/LoginForm.vue:32` handles missing/empty email with readable required copy, other invalid email with format guidance, and undefined/empty passwords with required copy while keeping the prior minimum. Server/API failure behavior is untouched.
- `QuotaForms.test.ts:59` and `LoginForm.test.ts:51` pass the actual SFC schemas and actual handlers through the shared harness. Account/auth composables are real; only API boundaries and UI primitives are substituted. Exact request bodies, omitted quota, numeric zero/positive quota, invalid-input zero-request behavior and server-error guidance are meaningful assertions. The simulated stored account alone would not prove persistence, but the tests also verify the production API request construction. Independent Task 1 review reports 57/57 focused tests passed.

### Webhook controls, picker names and table controls

- `manager/app/components/instances/WebhookCard.vue:24` creates a component-scoped useId prefix; each event adds its suffix at `:158`. The installed useFormField gives explicit IDs priority, and Checkbox uses the resulting ID for both root and label target. Events therefore no longer inherit one shared form-field ID, including when multiple editors mount.
- Subscription logic and save payload are preserved: contract ordering at `WebhookCard.vue:57`, All/None at `:60`/`:64`, true-only addition at `:162`, and URL/enabled/events payload at `:75`. The new tests exercise real event handlers, reverse-order changes, removal, and explicit empty events/URL with disabled state. They stub the composable and cannot prove server persistence or DOM label clicks; those remain browser checks. Independent Task 2 review reports both tests passed.
- Supported localized FileUpload label props name the visible role-button in ProfileCard (`:137`), GroupDetail (`:314`), ChannelsCard (`:250`), MessageComposer (`:298`) and TestSendCard (`:542`). Installed FileUpload renders this text inside the focusable dropzone, unlike arbitrary ARIA attributes forwarded to its hidden input. Existing input models and handlers are untouched.
- Participant action (`GroupDetail.vue:331`), status kind (`ChannelsCard.vue:243`) and default disappearing timer (`InstanceSettingsSection.vue:191`) get localized aria-labels forwarded by the installed Select to its real trigger. Selection values and behavior are preserved.
- `manager/app/components/shared/DataTableToolbar.vue:42` hides the dropdown only for an empty optional-column list. Both table consumers derive this list from getCanHide (`InstancesTable.vue:132`, `AccountsTable.vue:128`); account visibility callbacks remain at `AccountsTable.vue:136`. Required instance columns remain locked, and account selection/actions are untouched.

### Theme, navigation and preservation

Task 3 spec and quality verdicts are both **PASS**, with evidence and the independent 8/8 focused test run in task-3-review.md. Light semantic aliases and three narrow button state overrides integrate through the existing design system. Installed CSS predicts passing contrast for the inspected current variants; **none of those ratios is claimed as a rendered browser measurement**.

`InstanceSectionNav.vue:8` keeps all seven full labels; mobile model selection and desktop callbacks feed the same page section state. Mobile has a localized name and 44px minimum trigger; desktop retains active-state behavior. `[id].vue:42`/`:50` preserve query synchronization. The only page delta is the back-action name at `:128`, leaving earlier alias/UUID canonicalization, stale-response protection and section data wiring intact. The independent focused run passed all five existing detail identity tests as well as the three new nav tests.

The remaining picker/selector edits add names only, quota changes are confined to the existing parser/schema boundary, and locale changes only add the required five keys. No contract, dependency, backend, migration, workflow, lockfile or generated artifact change appears in the 22-file package.

## Remaining delivery checks

The coordinator owns the full tests/lint/typecheck/build and actual agent-browser checks: light/dark rendered contrast (including opacity, hover/press and nested retries), 320/390px and desktop section labels/selection/URL behavior, numeric quota creation/editing/persistence, real webhook label clicks/save/reload, visible picker names and selected/removed states, and both table Display flows. Unit tests do not establish Nuxt UI DOM accessibility or responsive layout. No implementation revision is requested by this review.

Only this report and task-3-review.md were authored. No browser, child agents, source edits, commits, dependency installation or integration-test claims.

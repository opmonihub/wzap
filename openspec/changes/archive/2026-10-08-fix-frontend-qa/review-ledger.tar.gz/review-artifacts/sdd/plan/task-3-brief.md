## Task 3: Theme and responsive navigation (1.3)

Files: `manager/app/assets/css/main.css`, `manager/app/app.config.ts` if necessary, `manager/app/pages/instances/[id].vue`, `manager/app/components/instances/detail/InstanceSectionNav.vue`, meaningful navigation tests.

1. Inspect installed Nuxt UI semantic aliases and NavigationMenu/SelectMenu APIs; use pre-fix computed contrast and mobile screenshots as failing visual evidence.
2. Override light semantic tokens to suitable existing darker shades; preserve dark aliases, ensure white normal text on primary solid and error actions and colored text on subtle feedback meet 4.5:1 including hover. Avoid blanket global overrides of component internals.
3. Name back action using existing `instances.title` copy (or request a dedicated locale key).
4. At mobile widths provide a labelled selector displaying the full selected section and all seven full choices; keep desktop navigation and section/URL behavior. Minimum accessible mobile tap height 44px. Do not rely on truncated labels or hidden core sections.
5. Run focused tests for actual emitted section selection/current choice. Controller visually checks 320/390px and desktop, light/dark, form errors and alerts, with rendered contrast measurements.


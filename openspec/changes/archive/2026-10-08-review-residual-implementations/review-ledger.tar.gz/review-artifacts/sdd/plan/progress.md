# SDD ledger — plan: openspec/changes/review-residual-implementations/plan.md

Baseline: main HEAD f9d1300. Alterações locais preexistentes preservadas em manifest de hashes `/tmp/wzap-review-original-state.json`; worktree .worktrees/review-residual-implementations, branch codex/review-residual-implementations. Não commit/merge/deploy.

Review inicial: API (7 achados), core (4 achados), manager (5 achados), operações/gates (coordenador). Core segunda passagem read-only em andamento para fechar cobertura.

Baseline Go: full test exit 0; vet/build exit 0; golangci-lint v2.13.2 exit 0, 0 issues. Manager: Vitest 7/7, node:test 7/7, lint/typecheck/build exit 0; 2 warnings preexistentes. Integrações não habilitadas na baseline.

Planejamento: proposal, design, 7 deltas de specs, tasks, plan e brainstorm completos; OpenSpec strict PASS; apply pronto, 0/17 tasks concluídas. Definição de três áreas de escrita disjuntas; revisão cruzada antes de entrega.

Task 1: in progress (fix_api) (API/auth; tasks 1.1–1.6).
Task 2: pending (core; tasks 2.1–2.4).
Task 3: in progress (fix_manager) (manager; tasks 3.1–3.5).
Task 4: in progress (segunda revisão read-only).
Task 5: pending (gates/revisão/entrega local).

Task 4: complete — segunda passagem concluiu toda cobertura planejada; 7 achados adicionais confirmados + extensão de C3. Receipts RED real Postgres isolado exit 1 (/tmp/wzap-review-receipts-probe.log).
Task 2: in progress (fix_core), incluindo segurança/import/lifecycle; receipts e durabilidade reservados à Task 6.
Task 6: pending — writer disjunto message/storage/events assim que slot liberar.
O1: placeholder .gitkeep criado e intent-to-add no worktree; Go fresh-worktree passa a compilar sem Nuxt.
Scope: 24 causas confirmadas em review.md; tasks atualizadas antes da edição.

Task 1 progress: RED observados para sessão removida/demovida, replay corrupto, limiter overflow, métodos/alvos e multipart; GREEN parcial comunicado para auth/idem/JSON; focused completo em andamento.
Task 3 progress: perfil 6 RED -> 8 GREEN; detalhe alias 5 RED -> 5 GREEN; harness SFC real com Vue renderer, sem deps.
Task 2 progress: redirect/Token-prefix RED incluindo PostgreSQL isolado, GREEN em andamento; demais subtarefas em execução.

Task 1: implementation complete — sete causas corrigidas; focused API/auth exit 0, gofmt/diff clean; revisão cruzada em andamento (review_manager).
Task 3: implementation complete — 5 fluxos; 41 regressões novas, Vitest 48/48 + Node 7/7, lint/typecheck/build exit 0; 2 warnings preexistentes.
Task 6: in progress (fix_durability) — RED receipts real reproduzido; transação state+event_outbox, retry estável e notifier pós-commit aprovados. cmd/main liberado por Task 2.
O1: coordenador acrescentou passo Node/fs depois de Nuxt para restaurar placeholder; validação build/fresh embed pendente.

O1 complete — build Nuxt exit 0 conserva index + .gitkeep; pacote manager real sem assets compila/build/test e Handler dá 503 em probe isolado.
Task 1 re-review: complemento A4 confirmado (data null/scalar/array), 3 RED permanentes; validação mínima ajustada pelo coordenador, focused GREEN aguardando contratos do writer durability recompilarem.

Task 2 implementation complete — 9 áreas, focused/race com DB/schema isolado GREEN; fixture reconnect agora determinística, RED2/100 -> GREEN100/100; produção congelada. Revisão independente review_manager em andamento.
Task 6 implementation complete — receipts/terminal atomic; focused e race Postgres GREEN; root review estática sem findings materiais, segunda review fix_core em andamento.
Task 5 in progress — manager final48/48 + Node7/7, lint0errors/2baselinewarnings, typecheck/build0; Swaggerfreshness0, OpenSpecstrict0/gofmtclean; full Go SQL+NATS/vet/build/lint em execução com sources congeladas.

Review complete — Task1/A4, Task2 e Task3/O1 aprovados por review_manager; Task6 por fix_core + root. Nenhum P1/P2 material aberto no patch. Probe independente lote/cancelamento race10GREEN.
Delivery patch prepared and git apply --check main exit0; files controlled by code-manifest, no user-context overlays. Waiting full Go SQL+NATS gate before applying.

Task 5 complete — full Go SQL+NATS exit0 (3044PASS,1231topPASS, S3onlyskip), vet/lint/build0; sources identical applied main, smoke/build/Vitest48PASS; originals hashes preserved, old generated bundle backed up. Broker stopped and test env removed. verify/retrospective written, 25/25 tasks checked; final OpenSpec/diff/source+artifact hashes next.

Final checks PASS — OpenSpec strict WT/main0, applyall_done25/25; 86source/test hashes + 26artifacts equal; originals preserved, no staged changes, docs fresh, diffclean. Ephemeral NATS/env removed. Authorized local review/refactor objective completed; no commit/deploy/archive.

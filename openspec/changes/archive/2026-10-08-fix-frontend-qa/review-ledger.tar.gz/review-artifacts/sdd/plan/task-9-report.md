# Task 9: muted-text contrast follow-up

Implemented the single authorized production delta in `manager/app/assets/css/main.css:27`: add `--ui-text-muted: var(--ui-color-neutral-600)` to the existing `:root:not(.dark), .light` rule. All prior semantic corrections remain intact. No other production file, dependencies, tests, browser sessions, builds, commits, generated output, or primary-workspace files were changed.

## Observed failing evidence

Controller capture `dogfood-output/frontend-2026-10-07/after-group-controls-a11y.json` reports the group avatar fallback `Qg`, `span.font-medium.truncate.text-muted`, at 16px. Axe measured foreground `#71717b` on background `#f4f4f5` at **4.39:1**, below 4.5:1. The finding supports changing the used muted text token; no new CSS-constant test was added.

Installed Nuxt UI `manager/node_modules/@nuxt/ui/dist/runtime/index.css:1` maps light muted text to neutral500, toned text to neutral600, normal text to neutral700, muted surface to neutral50, elevated surface to neutral100. Dark muted text maps independently to neutral400. `manager/app/app.config.ts:5` maps neutral to existing zinc palette. `manager/node_modules/@nuxt/ui/dist/runtime/plugins/colors.js:13` generates the neutral shade aliases from that mapping, with installed Tailwind palette fallbacks. Avatar uses `text-muted` for fallback/icon at `manager/.nuxt/ui/avatar.ts:64`.

## Palette calculation evidence

Executed a read-only Node script from `manager/` using installed `tailwindcss/colors`. Converted OKLCH through OKLab to sRGB, then applied WCAG relative luminance and contrast calculations. Subtle surface is neutral100 at 50% over white. Values are predictions from installed palette data, not rendered after-proof.

| Foreground | White | Muted neutral50 | Elevated neutral100 (avatar) | Subtle neutral100/50 |
|---|---:|---:|---:|---:|
| Existing zinc500 | 4.828 | 4.625 | 4.387 | 4.605 |
| Corrected zinc600 | 7.730 | 7.403 | 7.024 | 7.371 |

Zinc600 is the next existing palette shade, approximately RGB(81.901, 81.878, 92.337), and clears 4.5 on all four current neutral surfaces. Zinc500 calculations reproduce the supplied 4.39 failure. The correction shares the existing toned-text shade, keeps normal neutral700 text stronger, and preserves the palette and all dark aliases.

## Dependent placeholders and scope

The current generated input/textarea use `placeholder:text-dimmed` at `manager/.nuxt/ui/input.ts:31` and `manager/.nuxt/ui/textarea.ts:31`; Select uses a `text-dimmed` placeholder at `manager/.nuxt/ui/select.ts:45`. This muted-only correction does not alter those placeholders. Select empty text and item descriptions do use muted, so they benefit from the same correction (`select.ts:50`, `select.ts:69`). Light dimmed remains neutral400 and darker-mode mappings remain untouched. No speculative change to the distinct dimmed/toned/normal tokens was made.

## Verification and handoff

`git diff --check` passed (exit 0). Impeccable detector on the sole changed production CSS target returned `[]` (exit 0). No behavior tests were added for a one-line token correction. Controller owns rendered after-proof, browser/a11y validation and final manager gates. This worker does not claim browser contrast is fixed until that after-proof runs.

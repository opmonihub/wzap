# Task 2 independent spec and quality review

Spec verdict: PASS for the scoped implementation. Quality verdict: PASS. No code blockers found. Overall frontend completion remains subject to the coordinator's required browser validation and full gates.

## Scope and evidence

Reviewed task-2-brief.md, task-2-report.md, the Task 2 deltas in task-2-review-package.md, the eight named UI files and WebhookCard.test.ts. Used /tmp/wzap-frontend-labels-inspection.md and confirmed the relevant installed Nuxt UI primitive implementation. Task 1, earlier snapshot changes and locale differences were excluded. No browser, child agents, commits or dependency changes.

- Component-scoped IDs: `manager/app/components/instances/WebhookCard.vue:24` calls Vue `useId()` once per component, and `:158` appends each unique event type. Thus explicit IDs separate events and multiple mounted editors. Installed `manager/node_modules/@nuxt/ui/dist/runtime/composables/useFormField.js:52` gives the explicit prop priority over the injected form-field ID. Installed `Checkbox.vue:77` uses the resulting ID for the checkbox root and `:96` uses it for the native label target. The event text remains the label at `WebhookCard.vue:161`; dots in event names are valid ID characters.
- Subscription and save behavior preserved: the review-package delta changes only ID declaration/binding in WebhookCard. The existing handlers retain contract ordering at `WebhookCard.vue:57`, All/None at `:60` and `:64`, true-only addition at `:162`, enabled URL validation at `:31`, and the existing URL/enabled/events save payload at `:75`. The PATCH composable is neither changed nor replaced by this fix.
- Every scoped visible file picker gets the supported localized label: `ProfileCard.vue:137`, `GroupDetail.vue:314`, `ChannelsCard.vue:250`, `MessageComposer.vue:298`, `TestSendCard.vue:542`. Installed `manager/node_modules/@nuxt/ui/dist/runtime/components/FileUpload.vue:220` defines the visible role-button, and `:242`/`:244` put the label text inside it. This correctly names the interactive picker; an external ARIA attribute would reach the hidden native input at `:274`. The existing picker behavior and defaults remain in place, including outside previews and keyboard activation.
- Correct selector targets: `GroupDetail.vue:331` names participant action, `ChannelsCard.vue:243` names status media kind, and `detail/InstanceSettingsSection.vue:191` names the default disappearing timer. Installed `manager/node_modules/@nuxt/ui/dist/runtime/components/Select.vue:192`/`:197` forwards caller attributes to the visible SelectTrigger. These additions use existing locale keys and do not change selected values or action handlers.
- Empty Display menu: `manager/app/components/shared/DataTableToolbar.vue:42` removes the dropdown only when its optional-column list is empty. Nonempty lists still use the existing items at `:43` and the same trigger at `:46`; no column definitions or visibility handlers are changed. This preserves the existing required-column policy and the Accounts menu path by construction. Consumer rendering and toggling still need the coordinator's actual-browser check.

## Test quality and verification

`manager/app/components/instances/WebhookCard.test.ts:47` clears the original message subscription, changes group.info and receipt in reverse order, and verifies the saved contract-order payload with no message entry at `:53`. The second test at `:58` exercises All, removal using indeterminate, None, disabling and an explicitly empty URL/events payload at `:71`. These exercise component handlers and save payloads rather than mirroring added attributes.

Ran `pnpm --config.verify-deps-before-run=false --dir manager test app/components/instances/WebhookCard.test.ts` in the worktree: exit 0, one file and both tests passed. The composable and UI primitives are mocked, so this does not prove HTTP persistence or real DOM accessibility.

## Remaining completion gates

No implementation revision is requested. Before overall UI completion, the coordinator must exercise actual checkbox labels and save/reload subscriptions; validate five file-picker names and keyboard/file selection/removal states; validate three Select names and changes; check desktop/narrow rendering; and confirm Instances omits the empty Display menu while Accounts retains toggling. Capture browser screenshots/results under the repository AGENTS.md requirement. Full frontend gates also remain coordinator-owned.

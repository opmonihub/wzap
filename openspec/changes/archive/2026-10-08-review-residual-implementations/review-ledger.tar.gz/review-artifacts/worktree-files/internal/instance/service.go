// Package instance implements the instance management service: creation,
// lookup, paginated listing, partial updates and removal of WhatsApp
// instances.
package instance

import (
	"context"
	"errors"
	"fmt"
	"strings"
	"time"

	"github.com/google/uuid"
	"github.com/rs/zerolog"

	"wzap/internal/auth"
	"wzap/internal/instancelock"
	"wzap/internal/model"
	"wzap/internal/session"
	"wzap/internal/storage"
	"wzap/internal/webhook"
)

// Errors reported by the service and mapped to HTTP status codes by the
// handler layer.
var (
	// ErrInstanceNameTaken reports a globally occupied exact instance name.
	ErrInstanceNameTaken = errors.New("instance name already taken")
	// ErrInvalidInstanceName reports an unsafe or reserved name.
	ErrInvalidInstanceName = errors.New("invalid instance name")
	// ErrNotFound reports that the requested instance does not exist.
	ErrNotFound = errors.New("instance not found")
	// ErrExternalRefTaken reports that an instance external_ref is already in use.
	ErrExternalRefTaken = errors.New("external ref already taken")
	// ErrInvalidCursor reports that a list cursor is not a valid identifier.
	ErrInvalidCursor = errors.New("invalid cursor")
	// ErrAlreadyConnected reports that a pairing request hit an instance whose
	// session is already connected.
	ErrAlreadyConnected = errors.New("instance already connected")
	// ErrOwnerRequired reports that Create received no owner. The handler
	// always resolves the owner before calling, so this is a programmer
	// error answered 500.
	ErrOwnerRequired = errors.New("owner is required")
	// ErrOwnerNotFound reports that the requested owner matches no user. The
	// handler maps it to 422: creation-input validation.
	ErrOwnerNotFound = errors.New("owner not found")
	// ErrNoAdmin reports that no admin user exists to own an instance created
	// without an explicit owner. It is only reachable pre-seed and the
	// handler maps it to 500: server state, not client error.
	ErrNoAdmin = errors.New("no admin user exists")
	// ErrInvalidWebhook reports that a webhook configuration failed
	// validation (non-HTTP(S) URL, HTTP outside loopback, or an unknown event
	// type). The handler maps it to 422 and the failed write persists
	// nothing.
	ErrInvalidWebhook = errors.New("invalid webhook config")
	// ErrNotConnected reports that an operation needed a connected session
	// while the instance session is offline. The handler maps it to 409.
	ErrNotConnected = errors.New("instance not connected")
	// ErrInvalidInput reports that an operation target (chat, sender or
	// message id) or payload is invalid. The handler maps it to 422.
	ErrInvalidInput = errors.New("invalid operation input")
	// ErrNoPairingChannel reports that phone pairing found no open pairing
	// channel: PairPhone needs a prior Connect, like the QR flow. The
	// handler maps it to 409.
	ErrNoPairingChannel = errors.New("no open pairing channel")
)

// ConnectResult is the outcome of a pairing request: the resulting status and,
// while pairing, the QR code and its validity.
type ConnectResult struct {
	Status      session.Status
	QRCode      string
	QRExpiresAt *time.Time
}

// PairPhoneResult is the outcome of a phone pairing request: the 8-digit
// code and the expiry of the pairing channel it was issued on.
type PairPhoneResult struct {
	Code      string
	ExpiresAt time.Time
}

// HealthResult is the websocket health check of an instance: the DB-persisted
// status (instances.status, atualizado pelos eventos de conexão) ao lado do
// estado vivo do socket. DBStatus "connected" com SocketConnected false é o
// sintoma clássico do socket morto: o banco ainda não viu o drop. HasSession
// false significa que não há sessão em memória (nunca pareada ou removida),
// então LiveStatus é disconnected e SocketConnected é false.
type HealthResult struct {
	DBStatus        string
	LiveStatus      session.Status
	SocketConnected bool
	HasSession      bool
}

// MediaRemover deletes the media files and rows of an instance. It is declared
// here, at the consumer, and will be satisfied by the media package (Task 16).
type MediaRemover interface {
	DeleteByInstance(ctx context.Context, instanceID uuid.UUID) error
}

// CreateInput is the payload accepted by Create. Name and ExternalRef are the
// fields the REST contract exposes; OwnerUserID is resolved by the handler
// from the request scope and is required non-nil at this boundary. The webhook
// fields are pointers so an absent field is distinct from an explicit value:
// an absent URL stays unset, an absent enabled stays false, and absent events
// default to every canonical type.
type CreateInput struct {
	Name           string
	ExternalRef    string
	OwnerUserID    *uuid.UUID
	WebhookURL     *string
	WebhookEnabled *bool
	WebhookEvents  *[]string
}

// UpdateInput is a partial update: nil fields keep their stored value, while an
// explicit empty ExternalRef clears the reference. The webhook fields follow
// the same rule: an absent URL, enabled, or events pointer leaves the stored
// configuration untouched, while an explicit empty URL unsets it and an
// explicit empty events list clears the subscription (delivering nothing).
type UpdateInput struct {
	Name           *string
	ExternalRef    *string
	WebhookURL     *string
	WebhookEnabled *bool
	WebhookEvents  *[]string
}

// Service manages the lifecycle of WhatsApp instances over the instance
// repository, the session manager, the media remover, the user repository
// (owner validation and oldest-admin lookup) and the API key repository (hash
// persist).
type Service struct {
	repo     storage.InstanceRepository
	sessions session.Manager
	media    MediaRemover
	users    storage.UserRepository
	keys     storage.APIKeyRepository
	// groups and newsletters are the optional group/channel metadata caches:
	// nil skips the write-through and leaves UpdatedAt zero.
	groups      storage.GroupMetadataRepository
	newsletters storage.NewsletterMetadataRepository
	log         zerolog.Logger
	// updateLocks only serializes partial instance patches. It is separate
	// from the WhatsApp send/import locks, which lifecycle callers may hold.
	updateLocks instancelock.Locker
}

const (
	msgConnectBranch = "connect instance branch"
	msgConnectFailed = "connect instance failed"
	msgQRBranch      = "qr instance branch"
	msgQRFailed      = "qr instance failed"
)

// ServiceOption customizes a Service.
type ServiceOption func(*Service)

// WithMetadataStores wires the group and channel metadata caches consumed by
// the refresh-on-demand write-through: every live group/channel read upserts
// its row and exposes the stored updated_at. Either store may be nil to skip
// its cache.
func WithMetadataStores(groups storage.GroupMetadataRepository, newsletters storage.NewsletterMetadataRepository) ServiceOption {
	return func(s *Service) {
		s.groups = groups
		s.newsletters = newsletters
	}
}

// NewService builds the service over its dependencies. media may be nil until
// instance media exists (Task 16); Delete then skips media removal. users and
// keys are required for Create; a nil one fails Create with a 500-mapped
// error instead of panicking.
func NewService(repo storage.InstanceRepository, sessions session.Manager, media MediaRemover, users storage.UserRepository, keys storage.APIKeyRepository, log zerolog.Logger, opts ...ServiceOption) *Service {
	svc := &Service{repo: repo, sessions: sessions, media: media, users: users, keys: keys, log: log}
	for _, opt := range opts {
		opt(svc)
	}
	return svc
}

// Create registers a new instance in the disconnected state owned by
// input.OwnerUserID and emits its instance API key. The owner must resolve to
// an existing user; only the key hash is persisted via the keys repository,
// so the plaintext key exists in memory only and is returned here exactly
// once — never in a column, log or error. When the key mint or the hash
// persist fails after the row was inserted, the row is deleted again so a
// client retry starts clean instead of colliding with the orphaned row.
func (s *Service) Create(ctx context.Context, input CreateInput) (*model.Instance, string, error) {
	if err := ValidateInstanceName(input.Name); err != nil {
		return nil, "", fmt.Errorf("create instance: %w", err)
	}
	if input.OwnerUserID == nil {
		return nil, "", fmt.Errorf("create instance: %w", ErrOwnerRequired)
	}
	// The webhook configuration is pure input validation and runs before any
	// database read or write, so a 422 never partially persists.
	rawURL := ""
	if input.WebhookURL != nil {
		rawURL = *input.WebhookURL
	}
	webhookURL, webhookEvents, err := webhook.ValidateConfig(rawURL, input.WebhookEvents)
	if err != nil {
		return nil, "", fmt.Errorf("create instance: %w (%v)", ErrInvalidWebhook, err)
	}
	webhookEnabled := false
	if input.WebhookEnabled != nil {
		webhookEnabled = *input.WebhookEnabled
	}
	if s.users == nil {
		return nil, "", fmt.Errorf("create instance: users repository is not configured")
	}
	if _, err := s.users.GetByID(ctx, *input.OwnerUserID); err != nil {
		if errors.Is(err, storage.ErrNotFound) {
			return nil, "", fmt.Errorf("create instance: %w", ErrOwnerNotFound)
		}
		return nil, "", fmt.Errorf("create instance: get owner: %w", err)
	}
	if s.keys == nil {
		return nil, "", fmt.Errorf("create instance: keys repository is not configured")
	}

	instance := model.Instance{
		ID:          uuid.New(),
		Name:        input.Name,
		ExternalRef: input.ExternalRef,
		OwnerUserID: input.OwnerUserID,
		Connection: model.InstanceConnection{
			Status: string(session.StatusDisconnected),
		},
		Webhook: model.InstanceWebhook{
			URL:       webhookURL,
			IsEnabled: webhookEnabled,
			Events:    webhookEvents,
		},
	}

	created, err := s.repo.Create(ctx, instance)
	if err != nil {
		return nil, "", mapError("create instance", err)
	}

	key, hash, err := auth.MintAPIKey()
	if err != nil {
		return nil, "", s.deleteCreated(ctx, created.ID, fmt.Errorf("mint api key: %w", err))
	}
	if err := s.keys.SetHash(ctx, created.ID, hash); err != nil {
		return nil, "", s.deleteCreated(ctx, created.ID, fmt.Errorf("store key hash: %w", err))
	}
	return created, key, nil
}

// deleteCreated removes a just-inserted instance after a post-insert failure
// (key mint or hash persist). A failed compensation is loud: the returned
// error mentions both faults, mirroring the seed rollback.
func (s *Service) deleteCreated(ctx context.Context, id uuid.UUID, cause error) error {
	if err := s.repo.Delete(ctx, id); err != nil {
		return fmt.Errorf("create instance: %v; compensating instance delete also failed: %w", cause, err)
	}
	return fmt.Errorf("create instance: %w", cause)
}

// OldestAdmin returns the id of the admin user with the earliest created_at.
// users.List arrives ordered by created_at, so the first role==admin row wins.
// It reports ErrNoAdmin when no admin user exists.
func (s *Service) OldestAdmin(ctx context.Context) (uuid.UUID, error) {
	if s.users == nil {
		return uuid.Nil, fmt.Errorf("resolve oldest admin: users repository is not configured")
	}
	users, err := s.users.List(ctx)
	if err != nil {
		return uuid.Nil, fmt.Errorf("resolve oldest admin: %w", err)
	}
	for i := range users {
		if users[i].Role == "admin" {
			return users[i].ID, nil
		}
	}
	return uuid.Nil, fmt.Errorf("resolve oldest admin: %w", ErrNoAdmin)
}

// Get returns the instance with the given id or ErrNotFound.
func (s *Service) Get(ctx context.Context, id uuid.UUID) (*model.Instance, error) {
	instance, err := s.repo.Get(ctx, id)
	if err != nil {
		return nil, mapError("get instance", err)
	}
	return instance, nil
}

// GetByName returns the unique instance with this exact name.
func (s *Service) GetByName(ctx context.Context, name string) (*model.Instance, error) {
	instance, err := s.repo.GetByName(ctx, name)
	if err != nil {
		return nil, mapError("get instance by name", err)
	}
	return instance, nil
}

// Health returns the DB-persisted status of the instance alongside the live
// socket state, without creating a session: a read-only peek through
// sessions.Get. An unknown instance is ErrNotFound.
func (s *Service) Health(ctx context.Context, id uuid.UUID) (HealthResult, error) {
	stored, err := s.repo.Get(ctx, id)
	if err != nil {
		return HealthResult{}, mapError("health instance", err)
	}
	result := HealthResult{DBStatus: stored.Connection.Status, LiveStatus: session.StatusDisconnected}
	if sess, ok := s.sessions.Get(id); ok && sess != nil {
		result.HasSession = true
		result.LiveStatus = sess.Status()
		result.SocketConnected = sess.IsConnected()
	}
	return result, nil
}

// List returns every instance ordered by created_at descending, then id descending.
func (s *Service) List(ctx context.Context) ([]model.Instance, error) {
	instances, err := s.repo.List(ctx)
	if err != nil {
		return nil, mapError("list instances", err)
	}
	return instances, nil
}

// Update applies the fields present in input to the stored instance and
// returns the stored aggregate. The write is split per concern: identity
// fields go through UpdateIdentity and the webhook fields through
// SetWebhook, so neither command can resurrect a stale connection state.
func (s *Service) Update(ctx context.Context, id uuid.UUID, input UpdateInput) (*model.Instance, error) {
	if err := ctx.Err(); err != nil {
		return nil, mapError("update instance", err)
	}
	release, err := s.updateLocks.Acquire(ctx, id)
	if err != nil {
		return nil, mapError("update instance", err)
	}
	defer release()

	instance, err := s.repo.Get(ctx, id)
	if err != nil {
		return nil, mapError("update instance", err)
	}

	name := instance.Name
	if input.Name != nil {
		// Names are globally unique and always valid on create, so every
		// rename/update input is validated — including one equal to the
		// stored name (which stays a successful no-op rename).
		if err := ValidateInstanceName(*input.Name); err != nil {
			return nil, fmt.Errorf("update instance: %w", err)
		}
		name = *input.Name
	}
	externalRef := instance.ExternalRef
	if input.ExternalRef != nil {
		externalRef = *input.ExternalRef
	}

	// Only the webhook fields present in the patch are validated and applied;
	// absent ones keep the stored configuration. Validation runs before any
	// write, so a 422 keeps the previous configuration.
	webhookChanged := input.WebhookURL != nil || input.WebhookEnabled != nil || input.WebhookEvents != nil
	webhookURL := instance.Webhook.URL
	webhookEnabled := instance.Webhook.IsEnabled
	webhookEvents := instance.Webhook.Events
	if input.WebhookURL != nil {
		normalized, err := webhook.ValidateURL(*input.WebhookURL)
		if err != nil {
			return nil, fmt.Errorf("update instance: %w (%v)", ErrInvalidWebhook, err)
		}
		webhookURL = normalized
	}
	if input.WebhookEnabled != nil {
		webhookEnabled = *input.WebhookEnabled
	}
	if input.WebhookEvents != nil {
		normalized, err := webhook.ValidateEvents(*input.WebhookEvents)
		if err != nil {
			return nil, fmt.Errorf("update instance: %w (%v)", ErrInvalidWebhook, err)
		}
		webhookEvents = normalized
	}

	// Identity first: a rejected rename (name taken/invalid) must not have a
	// webhook side effect already committed. The reverse order would leave a
	// half-applied patch; a webhook failure after a committed identity write
	// still leaves a consistent aggregate (500, retry is safe).
	updated := instance
	if input.Name != nil || input.ExternalRef != nil {
		updated, err = s.repo.UpdateIdentity(ctx, id, name, externalRef)
		if err != nil {
			return nil, mapError("update instance", err)
		}
	}
	if webhookChanged {
		if err := s.repo.SetWebhook(ctx, id, webhookURL, webhookEnabled, webhookEvents); err != nil {
			return nil, mapError("update instance", err)
		}
		updated.Webhook.URL = webhookURL
		updated.Webhook.IsEnabled = webhookEnabled
		updated.Webhook.Events = webhookEvents
	}
	return updated, nil
}

// Connect starts the pairing of a non-connected instance and answers the QR
// code with its validity. An instance whose session is already connected is a
// no-op that answers with its status and no QR, while an instance already
// pairing answers the current code instead of opening a second channel: both
// keep the operation idempotent. The pairing state is persisted before
// returning.
func (s *Service) Connect(ctx context.Context, id uuid.UUID) (ConnectResult, error) {
	instance, err := s.repo.Get(ctx, id)
	if err != nil {
		return ConnectResult{}, mapError("connect instance", err)
	}

	sess, err := s.sessionFor(ctx, instance)
	if err != nil {
		return ConnectResult{}, fmt.Errorf("connect instance: create session: %w", err)
	}

	// O Status sozinho pode dizer "connected" com o socket já morto (o
	// banco só vê o drop quando o evento chega): só é no-op quando o
	// websocket está vivo. Com o socket morto cai para o connectPairing
	// abaixo, que reabre o websocket em vez de responder connected com o
	// socket morto (que quebraria a resolução de números e os envios).
	if sess.Status() == session.StatusConnected && sess.IsConnected() {
		s.log.Debug().Str("instance_id", id.String()).Str("op", "connect").
			Str("branch", "already-connected").Str("status", string(session.StatusConnected)).
			Msg(msgConnectBranch)
		return ConnectResult{Status: session.StatusConnected}, nil
	}
	if sess.Status() == session.StatusPairing {
		result, err := pairingResult(ctx, sess)
		if err != nil {
			s.log.Warn().Str("instance_id", id.String()).Str("op", "connect").
				Str("branch", "already-pairing").Err(err).Msg(msgConnectFailed)
			return ConnectResult{}, fmt.Errorf("connect instance: %w", err)
		}
		ev := s.log.Debug().Str("instance_id", id.String()).Str("op", "connect").
			Str("branch", "already-pairing").Str("status", string(result.Status)).
			Bool("qr_present", result.QRCode != "")
		if result.QRExpiresAt != nil {
			ev = ev.Time("expires_at", *result.QRExpiresAt)
		}
		ev.Msg(msgConnectBranch)
		return result, nil
	}

	_, qr, expiresAt, err := s.connectPairing(ctx, instance, sess, "connect")
	if err != nil {
		s.log.Warn().Str("instance_id", id.String()).Str("op", "connect").
			Str("branch", "new-pairing").Err(err).Msg(msgConnectFailed)
		return ConnectResult{}, fmt.Errorf("connect instance: %w", err)
	}
	if qr == "" {
		// The instance has stored credentials: connecting it online needs no
		// pairing, and the event sink persists the connected status. O
		// estado vivo do socket vai junto porque este ramo retornava
		// connected sem verificar o websocket.
		s.log.Debug().Str("instance_id", id.String()).Str("op", "connect").
			Str("branch", "stored-credentials").Str("status", string(session.StatusConnected)).
			Str("live_status", string(sess.Status())).Bool("socket_connected", sess.IsConnected()).
			Msg(msgConnectBranch)
		return ConnectResult{Status: session.StatusConnected}, nil
	}

	if err := s.markPairing(ctx, instance); err != nil {
		s.log.Warn().Str("instance_id", id.String()).Str("op", "connect").
			Str("branch", "persist-pairing").Err(err).Msg(msgConnectFailed)
		return ConnectResult{}, fmt.Errorf("connect instance: %w", err)
	}
	s.log.Debug().Str("instance_id", id.String()).Str("op", "connect").
		Str("branch", "new-pairing").Str("status", string(session.StatusPairing)).
		Bool("qr_present", true).Time("expires_at", expiresAt).
		Msg(msgConnectBranch)
	return ConnectResult{Status: session.StatusPairing, QRCode: qr, QRExpiresAt: &expiresAt}, nil
}

// QR returns the current pairing QR code of a non-connected instance. It
// starts the pairing when none is active, so an expired code is replaced. A
// connected instance is a conflict: it has no QR to scan.
func (s *Service) QR(ctx context.Context, id uuid.UUID) (ConnectResult, error) {
	instance, err := s.repo.Get(ctx, id)
	if err != nil {
		return ConnectResult{}, mapError("get qr", err)
	}

	sess, err := s.sessionFor(ctx, instance)
	if err != nil {
		return ConnectResult{}, fmt.Errorf("get qr: create session: %w", err)
	}

	// Como no Connect: só é 409 sem tocar no socket quando o websocket
	// está vivo. Com o socket morto cai para o connectPairing abaixo, que
	// reabre o websocket; como o dispositivo já tem credenciais o retorno
	// continua 409, mas com o socket revivido como efeito colateral.
	if sess.Status() == session.StatusConnected && sess.IsConnected() {
		s.log.Debug().Str("instance_id", id.String()).Str("op", "qr").
			Str("branch", "already-connected").Str("status", string(session.StatusConnected)).
			Msg(msgQRBranch)
		return ConnectResult{}, fmt.Errorf("get qr: %w", ErrAlreadyConnected)
	}
	if sess.Status() == session.StatusPairing {
		result, err := pairingResult(ctx, sess)
		if err != nil {
			s.log.Warn().Str("instance_id", id.String()).Str("op", "qr").
				Str("branch", "already-pairing").Err(err).Msg(msgQRFailed)
			return ConnectResult{}, fmt.Errorf("get qr: %w", err)
		}
		ev := s.log.Debug().Str("instance_id", id.String()).Str("op", "qr").
			Str("branch", "already-pairing").Str("status", string(result.Status)).
			Bool("qr_present", result.QRCode != "")
		if result.QRExpiresAt != nil {
			ev = ev.Time("expires_at", *result.QRExpiresAt)
		}
		ev.Msg(msgQRBranch)
		return result, nil
	}

	_, qr, expiresAt, err := s.connectPairing(ctx, instance, sess, "qr")
	if err != nil {
		s.log.Warn().Str("instance_id", id.String()).Str("op", "qr").
			Str("branch", "new-pairing").Err(err).Msg(msgQRFailed)
		return ConnectResult{}, fmt.Errorf("get qr: %w", err)
	}
	if qr == "" {
		// Stored credentials mean the instance is paired already; there is no
		// QR to hand out. O estado vivo do socket vai junto (efeito
		// colateral de reviver o websocket mesmo no 409).
		s.log.Debug().Str("instance_id", id.String()).Str("op", "qr").
			Str("branch", "stored-credentials").Str("status", string(session.StatusConnected)).
			Str("live_status", string(sess.Status())).Bool("socket_connected", sess.IsConnected()).
			Msg(msgQRBranch)
		return ConnectResult{}, fmt.Errorf("get qr: %w", ErrAlreadyConnected)
	}

	if err := s.markPairing(ctx, instance); err != nil {
		s.log.Warn().Str("instance_id", id.String()).Str("op", "qr").
			Str("branch", "persist-pairing").Err(err).Msg(msgQRFailed)
		return ConnectResult{}, fmt.Errorf("get qr: %w", err)
	}
	s.log.Debug().Str("instance_id", id.String()).Str("op", "qr").
		Str("branch", "new-pairing").Str("status", string(session.StatusPairing)).
		Bool("qr_present", true).Time("expires_at", expiresAt).
		Msg(msgQRBranch)
	return ConnectResult{Status: session.StatusPairing, QRCode: qr, QRExpiresAt: &expiresAt}, nil
}

// pairingResult reads the current code of an open pairing.
func pairingResult(ctx context.Context, sess session.Session) (ConnectResult, error) {
	qr, expiresAt, err := sess.QR(ctx)
	if err != nil {
		return ConnectResult{}, err
	}
	return ConnectResult{Status: session.StatusPairing, QRCode: qr, QRExpiresAt: &expiresAt}, nil
}

// sessionFor returns the session of instance, resetting a pairing whose
// persisted device is gone. The credentials cannot be recovered, so the
// instance is treated as unpaired: the stale JID is cleared and a fresh device
// is built so the caller can pair again instead of failing forever.
func (s *Service) sessionFor(ctx context.Context, instance *model.Instance) (session.Session, error) {
	if instance.BoundDeviceJID() != "" && session.NeedsFreshPairing(instance.LastErrorMessage()) {
		return s.resetPairing(ctx, instance)
	}
	sess, err := s.sessions.Create(instance)
	if err == nil {
		if instance.BoundDeviceJID() != "" && sess.Status() == session.StatusError && session.NeedsFreshPairing(instance.LastErrorMessage()) {
			return s.resetPairing(ctx, instance)
		}
		return sess, nil
	}
	if errors.Is(err, session.ErrNoDevice) || errors.Is(err, session.ErrDeviceJIDTaken) {
		return s.resetPairing(ctx, instance)
	}
	if strings.Contains(err.Error(), "device jid mismatch") {
		return s.resetPairing(ctx, instance)
	}
	return nil, err
}

// resetPairing forgets the unrecoverable pairing of instance and returns a
// fresh session ready to pair again. Removing the session first keeps the
// manager consistent when a session with a deleted device is still registered.
func (s *Service) resetPairing(ctx context.Context, instance *model.Instance) (session.Session, error) {
	s.log.Debug().Str("instance_id", instance.ID.String()).Str("branch", "reset-stale-device").Msg("reset stale pairing")
	if err := s.sessions.Remove(ctx, instance.ID); err != nil {
		return nil, fmt.Errorf("reset pairing: remove session: %w", err)
	}
	if err := s.repo.SetConnection(ctx, instance.ID, string(session.StatusDisconnected), ""); err != nil {
		return nil, mapError("reset pairing", err)
	}
	instance.Connection.DeviceJID = ""
	return s.sessions.Create(instance)
}

// connectPairing calls Session.Connect, resetting a pairing whose device was
// deleted underneath the session (an external logout) and retrying once. The
// op names the caller (connect or qr) for the boundary logs; error outcomes —
// including a context cancellation from Connect — are returned unchanged for
// the caller to log, so retry semantics are untouched.
func (s *Service) connectPairing(ctx context.Context, instance *model.Instance, sess session.Session, op string) (session.Session, string, time.Time, error) {
	qr, expiresAt, err := sess.Connect(ctx)
	if !errors.Is(err, session.ErrNoDevice) {
		return sess, qr, expiresAt, err
	}

	s.log.Debug().Str("instance_id", instance.ID.String()).Str("op", op).Str("branch", "reset-stale-device").Msg("connect pairing device gone, resetting stale pairing")
	sess, err = s.resetPairing(ctx, instance)
	if err != nil {
		return nil, "", time.Time{}, err
	}
	qr, expiresAt, err = sess.Connect(ctx)
	return sess, qr, expiresAt, err
}

// markPairing persists the pairing state of instance so the status endpoint
// reflects it and a restart can resume it. The write only touches the
// connection columns: a full-row update could resurrect a stale last_error set
// by a concurrent connection event.
func (s *Service) markPairing(ctx context.Context, instance *model.Instance) error {
	if err := s.repo.SetConnection(ctx, instance.ID, string(session.StatusPairing), instance.BoundDeviceJID()); err != nil {
		return mapError("update instance", err)
	}
	return nil
}

// Restore brings the persisted sessions back online at startup. The manager
// bounds the concurrency and reports each outcome through the connection
// events, which keep instances.status in sync; only listing the instances can
// fail the call.
func (s *Service) Restore(ctx context.Context) error {
	if err := s.sessions.RestoreAll(ctx); err != nil {
		return fmt.Errorf("restore sessions: %w", err)
	}
	return nil
}

// Disconnect ends the session of an instance definitively: it disconnects the
// session, clears its paired identity and connection state, and deletes the
// stored credentials so the instance cannot be brought back online without a
// new pairing. An instance whose device is already gone is treated as
// disconnected: the stale JID is cleared and 204 is answered. The session emits
// the connection event that records the transition; the partial update keeps
// other columns untouched. On a credential removal failure the row is already
// cleared, so retrying finishes the removal.
func (s *Service) Disconnect(ctx context.Context, id uuid.UUID) error {
	instance, err := s.repo.Get(ctx, id)
	if err != nil {
		return mapError("disconnect instance", err)
	}

	sess, err := s.sessionFor(ctx, instance)
	if err != nil {
		return fmt.Errorf("disconnect instance: create session: %w", err)
	}
	if err := sess.Disconnect(ctx); err != nil {
		return fmt.Errorf("disconnect instance: %w", err)
	}
	if err := s.repo.SetConnection(ctx, id, string(session.StatusDisconnected), ""); err != nil {
		return mapError("disconnect instance", err)
	}
	if err := s.sessions.Remove(ctx, id); err != nil {
		return fmt.Errorf("disconnect instance: remove session: %w", err)
	}
	return nil
}

// Delete tears the session down, deletes the instance media and finally removes
// the row. A failure aborts before the row is removed, keeping the instance
// available so the removal can be retried instead of leaking credentials or
// media.
func (s *Service) Delete(ctx context.Context, id uuid.UUID) error {
	if _, err := s.repo.Get(ctx, id); err != nil {
		return mapError("delete instance", err)
	}
	if err := s.sessions.Remove(ctx, id); err != nil {
		return fmt.Errorf("delete instance: remove session: %w", err)
	}
	if s.media != nil {
		if err := s.media.DeleteByInstance(ctx, id); err != nil {
			return fmt.Errorf("delete instance: delete media: %w", err)
		}
	}
	if err := s.repo.Delete(ctx, id); err != nil {
		return mapError("delete instance", err)
	}
	return nil
}

// RevokeMessage revokes a sent message for everyone in the chat through the
// instance session. It is synchronous and direct: no outbox, no retry. A
// disconnected session is ErrNotConnected and a malformed target is
// ErrInvalidInput; anything else is returned unchanged for a 500.
func (s *Service) RevokeMessage(ctx context.Context, id uuid.UUID, chatJID, messageID string) error {
	instance, err := s.repo.Get(ctx, id)
	if err != nil {
		return mapError("revoke message", err)
	}

	sess, err := s.sessionFor(ctx, instance)
	if err != nil {
		return fmt.Errorf("revoke message: create session: %w", err)
	}
	if err := sess.DeleteMessage(ctx, chatJID, messageID); err != nil {
		return mapSessionError("revoke message", err)
	}
	return nil
}

// MarkRead sends a read receipt for messageID in chatJID through the instance
// session. An empty senderJID falls back to the chat JID for direct chats;
// group reads carry the author. Error mapping follows RevokeMessage.
func (s *Service) MarkRead(ctx context.Context, id uuid.UUID, chatJID, senderJID, messageID string) error {
	instance, err := s.repo.Get(ctx, id)
	if err != nil {
		return mapError("mark read", err)
	}

	sess, err := s.sessionFor(ctx, instance)
	if err != nil {
		return fmt.Errorf("mark read: create session: %w", err)
	}
	if err := sess.MarkRead(ctx, chatJID, senderJID, messageID); err != nil {
		return mapSessionError("mark read", err)
	}
	return nil
}

// SendPresence reports chat presence ("composing"/"paused") or user presence
// ("available"/"unavailable") through the instance session. There is no
// continuous mode: one call publishes one signal. Error mapping follows
// RevokeMessage.
func (s *Service) SendPresence(ctx context.Context, id uuid.UUID, chatJID, state string) error {
	instance, err := s.repo.Get(ctx, id)
	if err != nil {
		return mapError("send presence", err)
	}

	sess, err := s.sessionFor(ctx, instance)
	if err != nil {
		return fmt.Errorf("send presence: create session: %w", err)
	}
	if err := sess.SendPresence(ctx, chatJID, state); err != nil {
		return mapSessionError("send presence", err)
	}
	return nil
}

// PairPhone requests the 8-digit pairing code for phone without scanning a QR
// code. The instance must hold an open pairing channel (Connect first): a
// connected instance is ErrAlreadyConnected and any other non-pairing state
// is ErrNoPairingChannel, both answered 409. The code expires with the QR
// channel, so the returned expiry is the channel expiry. The channel is never
// opened implicitly.
func (s *Service) PairPhone(ctx context.Context, id uuid.UUID, phone string) (PairPhoneResult, error) {
	instance, err := s.repo.Get(ctx, id)
	if err != nil {
		return PairPhoneResult{}, mapError("pair phone", err)
	}

	sess, err := s.sessionFor(ctx, instance)
	if err != nil {
		return PairPhoneResult{}, fmt.Errorf("pair phone: create session: %w", err)
	}
	switch sess.Status() {
	case session.StatusConnected:
		return PairPhoneResult{}, fmt.Errorf("pair phone: %w", ErrAlreadyConnected)
	case session.StatusPairing:
		// An open channel: request the code below.
	default:
		return PairPhoneResult{}, fmt.Errorf("pair phone: %w", ErrNoPairingChannel)
	}

	// Read the channel expiry before requesting the code: a channel that
	// expired or closed between the status check and the request must answer
	// 409 (no open pairing channel) without emitting a code the client would
	// never receive.
	_, expiresAt, err := sess.QR(ctx)
	if err != nil {
		return PairPhoneResult{}, fmt.Errorf("pair phone: %w", ErrNoPairingChannel)
	}
	code, err := sess.PairPhone(ctx, phone)
	if err != nil {
		return PairPhoneResult{}, mapSessionError("pair phone", err)
	}
	return PairPhoneResult{Code: code, ExpiresAt: expiresAt}, nil
}

// mapSessionError translates a session call failure into the service sentinel
// the HTTP layer maps to a status code, preserving the operation context for
// the logs. Unknown failures pass through unchanged for a 500 without leaking
// their cause (the handler never echoes them).
func mapSessionError(op string, err error) error {
	switch {
	case errors.Is(err, session.ErrNotConnected):
		return fmt.Errorf("%s: %w", op, ErrNotConnected)
	case errors.Is(err, session.ErrInvalidRecipient):
		return fmt.Errorf("%s: %w", op, ErrInvalidInput)
	case errors.Is(err, session.ErrUnsupported):
		return fmt.Errorf("%s: %w", op, ErrUnsupported)
	default:
		return fmt.Errorf("%s: %w", op, err)
	}
}

// mapError translates a storage error into the service sentinel the HTTP layer
// maps to a status code, preserving the operation context for the logs.
func mapError(op string, err error) error {
	switch {
	case errors.Is(err, storage.ErrNotFound):
		return fmt.Errorf("%s: %w", op, ErrNotFound)
	case errors.Is(err, storage.ErrInvalidInstanceName):
		return fmt.Errorf("%s: %w", op, ErrInvalidInstanceName)
	case errors.Is(err, storage.ErrInstanceNameTaken):
		return fmt.Errorf("%s: %w", op, ErrInstanceNameTaken)
	case errors.Is(err, storage.ErrExternalRefTaken):
		return fmt.Errorf("%s: %w", op, ErrExternalRefTaken)
	case errors.Is(err, storage.ErrInvalidCursor):
		return fmt.Errorf("%s: %w", op, ErrInvalidCursor)
	default:
		return fmt.Errorf("%s: %w", op, err)
	}
}

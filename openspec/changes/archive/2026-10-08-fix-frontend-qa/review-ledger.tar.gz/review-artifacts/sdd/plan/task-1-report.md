# Task 1: Forms (1.1)

Status: scoped implementation complete; focused tests and focused lint pass. Full manager gates and browser verification remain with the coordinator.

## Root cause evidence

- `manager/app/utils/accountQuota.ts:3` previously accepted only `string`; its old line 4 called `raw.trim()` without checking the model type. Numeric `0`/`2` and `undefined` therefore threw before quota normalization. The parser now accepts `string | number | undefined`, trims strings only, and keeps missing values distinct from explicit zero (`:4`, `:5`, `:9`).
- `manager/app/components/accounts/CreateAccountModal.vue:21` previously used `z.string()` for `instance_limit`; `manager/app/components/accounts/EditQuotaModal.vue:21` did the same. Nuxt UI converts numeric input values at `manager/node_modules/@nuxt/ui/dist/runtime/components/Input.vue:78` and `:79`. Both real component schemas rejected valid numbers before their real submission handlers could call the parser. They now accept strings/numbers/undefined and validate with the shared parser. Creation permits omission (`CreateAccountModal.vue:22`); editing rejects omission and blank input (`EditQuotaModal.vue:23`). Invalid inputs receive the existing quota messages at the field schema boundary.
- `manager/app/components/auth/LoginForm.vue:31` previously used `z.email()` and `z.string().min(1)` without validation copy. Nuxt UI initializes auth fields from `field.defaultValue` at `manager/node_modules/@nuxt/ui/dist/runtime/components/AuthForm.vue:45`; neither login field defines a default (`LoginForm.vue:39`). Untouched fields are therefore `undefined`, producing Zod's internal type errors. The schema now supplies localized required/invalid-email copy, including for undefined values (`LoginForm.vue:32`, `:35`).

## Scope and behavior

Production changes are limited to the four assigned files. Three focused test files were added in the assigned directories:

- `manager/app/utils/accountQuota.test.ts`: 18 parser cases cover missing/blank values, numeric and string zero, positive integers, negative/fractional values, NaN, infinities and invalid text.
- `manager/app/components/accounts/QuotaForms.test.ts`: 32 cases compile the actual SFCs and their schemas, drive their actual numeric model update handlers, and use the real `useAccounts` composable. Only UI primitives and the API boundary are replaced. Creation omission and numeric payloads are asserted at `:75` and `:86`; invalid creation guidance at `:98`; edit payloads at `:124`; required/invalid edits at `:136`. Duplicate-email/save failures retain entered values and render the server guidance (`:112`, `:151`).
- `manager/app/components/auth/LoginForm.test.ts`: 7 cases compile the actual login SFC/schema and use the real `useAuth` composable. Untouched and cleared fields show the requested copy (`:62`); invalid email stays blocked (`:75`); the existing one-character password minimum still succeeds (`:87`); API errors, empty-message fallback and network-error guidance remain intact (`:97`).

Blank creation omits `instance_limit` from the outgoing API body. Numeric/string `0` stays numeric `0`; numeric/string positive integers stay numeric. Editing requires a non-negative integer. Invalid data is rejected before an API request or success notice.

## RED evidence

No production files were changed before the regression run.

Working directory: `/home/obsidian/dev/wzap/.worktrees/fix-frontend-qa/manager`.

```sh
node node_modules/vitest/vitest.mjs run app/utils/accountQuota.test.ts app/components/accounts/QuotaForms.test.ts app/components/auth/LoginForm.test.ts
```

Exit 1; **3 files failed, 37 tests failed / 20 passed (57 total)**. Complete output: [task-1-red.log](task-1-red.log).

- Parser: 8 failures, including `raw.trim is not a function` for numeric zero/two and `Cannot read properties of undefined (reading 'trim')`.
- Compiled account forms: 26 failures. Creation `undefined`, numeric zero/two, and edit numeric zero/three failed the real schemas. Invalid numeric inputs showed `Invalid input: expected string, received number`; invalid string input passed the schemas and was only caught later by submission handlers.
- Compiled login form: 3 failures. Untouched fields showed `Invalid input: expected string, received undefined`; cleared/invalid-email cases also showed framework messages rather than the requested copy.
- The `%j` formatter labels NaN and infinities as `null` in the RED log; those test inputs are the explicit non-finite values in `accountQuota.test.ts:18`, `QuotaForms.test.ts:98` and `:136`, not null model values.

An earlier `pnpm --dir manager test ...` attempt did not run tests: pnpm's automatic dependency check attempted an install and refused the linked modules directory with `ERR_PNPM_UNSAFE_MODULES_DIR`. It is separate from the meaningful RED run. No install or dependency edit was performed. The coordinator supplied the `verify-deps-before-run=false` flag for subsequent pnpm commands.

## GREEN and focused verification

After the parser-only fix: direct Vitest on `app/utils/accountQuota.test.ts` exited 0, **18/18**.

After the account-schema fix: direct Vitest on `app/components/accounts/QuotaForms.test.ts` exited 0, **32/32**.

After the login-schema fix: direct Vitest on `app/components/auth/LoginForm.test.ts` exited 0, **7/7**.

Final command, run after test-fixture self-review fixes, from the worktree root:

```sh
pnpm --config.verify-deps-before-run=false --dir manager test app/utils/accountQuota.test.ts app/components/accounts/QuotaForms.test.ts app/components/auth/LoginForm.test.ts
```

Exit 0; **3 files passed, 57/57 tests passed**. Complete output: [task-1-green.log](task-1-green.log).

Focused lint, from the worktree's `manager` directory:

```sh
node node_modules/eslint/bin/eslint.js app/utils/accountQuota.ts app/utils/accountQuota.test.ts app/components/accounts/CreateAccountModal.vue app/components/accounts/EditQuotaModal.vue app/components/accounts/QuotaForms.test.ts app/components/auth/LoginForm.vue app/components/auth/LoginForm.test.ts
```

Exit 0, no diagnostics. Output file: [task-1-lint.log](task-1-lint.log). The first lint run found one `max-statements-per-line` violation in the new navigation fake; it was split across lines before the final run.

`git diff --check` exited 0. Impeccable's mechanical detector ran once over the three changed SFCs and returned `[]` (exit 0).

## Self-review and remaining concerns

- Verified the quota guard does not use truthiness: explicit zero cannot become omission. Removing the string/number union, the parser type guard, creation optionality or invalid/required refinements breaks the corresponding tests.
- Schemas validate the same shared parser used by submission handlers. The handlers still normalize before the API call and keep their existing defensive checks/server-error behavior.
- Numeric state types are inferred from the updated schemas, so the form models now accept the numeric input values without casts in production code.
- The account API fake mirrors all required `AccountUser` fields, including timestamps added during self-review. Tests exercise actual account/auth composables and actual SFC schemas/handlers, not duplicate validation logic.
- No changes were made outside the four production files, their three focused test files, and task evidence. Prior dirty manager files, locale JSON and generated files were left to their owners. No children, browser sessions, dependency changes or commits were made.
- Test output includes the existing component harness's informational Vue `<Suspense>` experimental-feature line. There are no test failures or lint diagnostics in the final runs.
- No unresolved implementation concern identified within this scope. Actual Nuxt UI form error rendering/responsive behavior still needs the coordinator's required browser pass; the focused harness substitutes UI primitives. Full manager test/lint/typecheck/build gates were intentionally left to the coordinator as instructed.

## Locale copy

The coordinator added and owns these keys; no additional keys are needed:

- `auth.emailRequired`: `Enter your email.`
- `auth.emailInvalid`: `Enter a valid email address.`
- `auth.passwordRequired`: `Enter your password.`

Existing `accounts.create.quotaInvalid` and `accounts.quota.quotaInvalid` are reused.

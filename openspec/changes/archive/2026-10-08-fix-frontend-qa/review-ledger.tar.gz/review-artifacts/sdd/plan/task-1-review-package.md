# New frontend QA deltas only

Baseline: snapshot of dirty manager taken before this QA correction round. Preserve all earlier changes.

Files:
- manager/app/components/accounts/CreateAccountModal.vue
- manager/app/components/accounts/EditQuotaModal.vue
- manager/app/components/accounts/QuotaForms.test.ts
- manager/app/components/auth/LoginForm.test.ts
- manager/app/components/auth/LoginForm.vue
- manager/app/utils/accountQuota.test.ts
- manager/app/utils/accountQuota.ts
- manager/i18n/locales/en.json

```diff
--- a/manager/app/components/accounts/CreateAccountModal.vue
+++ b/manager/app/components/accounts/CreateAccountModal.vue
@@ -13,17 +13,19 @@
 const { t } = useI18n()
 const toast = useToast()
 const { createUser } = useAccounts()
 
 const createSchema = z.object({
   email: z.string().min(1, t('accounts.create.emailRequired')).max(255),
   password: z.string().min(1, t('accounts.create.passwordRequired')),
   role: z.enum(['admin', 'user']),
-  instance_limit: z.string()
+  instance_limit: z.union([z.string(), z.number()], { error: t('accounts.create.quotaInvalid') })
+    .optional()
+    .refine(value => parseQuota(value) !== null, t('accounts.create.quotaInvalid'))
 })
 type CreateSchema = z.output<typeof createSchema>
 const createState = reactive<Partial<CreateSchema>>({ email: '', password: '', role: 'user', instance_limit: '' })
 const creating = ref(false)
 const createFailure = ref<string | null>(null)
 
 function resetCreate() {
   createState.email = ''
--- a/manager/app/components/accounts/EditQuotaModal.vue
+++ b/manager/app/components/accounts/EditQuotaModal.vue
@@ -13,17 +13,22 @@
 }>()
 const open = defineModel<boolean>('open', { default: false })
 
 const { t } = useI18n()
 const toast = useToast()
 const { updateUserQuota } = useAccounts()
 
 const quotaSchema = z.object({
-  instance_limit: z.string()
+  instance_limit: z.union([z.string(), z.number()], { error: t('accounts.quota.quotaInvalid') })
+    .optional()
+    .refine((value) => {
+      const quota = parseQuota(value)
+      return quota !== null && quota !== undefined
+    }, t('accounts.quota.quotaInvalid'))
 })
 type QuotaSchema = z.output<typeof quotaSchema>
 const quotaState = reactive<Partial<QuotaSchema>>({ instance_limit: '' })
 const quotaSaving = ref(false)
 const quotaFailure = ref<string | null>(null)
 
 watch([open, () => props.target], ([isOpen, target]) => {
   if (isOpen && target) {
--- a/manager/app/components/accounts/QuotaForms.test.ts
+++ b/manager/app/components/accounts/QuotaForms.test.ts
@@ -0,0 +1,160 @@
+import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
+import * as z from 'zod'
+import { ApiError } from '../../composables/useApi'
+import { useAccounts } from '../../composables/useAccounts'
+import type { AccountUser } from '../../types/api'
+import { parseQuota } from '../../utils/accountQuota'
+import {
+  installComponentGlobals, loadComponent, mountComponent, primitive, translate, unmountComponents
+} from '../../../tests/componentHarness'
+
+const accountId = '67a5b146-74e8-4fa5-b77d-dcd92fba7012'
+let stored: AccountUser
+let requests: { path: string, method?: string, body?: unknown }[]
+let notices: { title: string, color: string }[]
+let serverError: Error | null
+
+beforeEach(() => {
+  installComponentGlobals()
+  stored = {
+    id: accountId,
+    email: 'quota@example.com',
+    role: 'user',
+    instance_limit: 4,
+    instances_used: 0,
+    created_at: '2026-10-07T12:00:00Z',
+    updated_at: '2026-10-07T12:00:00Z'
+  }
+  requests = []
+  notices = []
+  serverError = null
+  vi.stubGlobal('useToast', () => ({ add: (notice: typeof notices[number]) => notices.push(notice) }))
+  vi.stubGlobal('useApi', () => ({
+    api: async (path: string, options?: { method: string, body?: unknown }) => {
+      requests.push({ path, ...options })
+      if (serverError) throw serverError
+      const body = options?.body as { email?: string, instance_limit?: number }
+      stored = { ...stored, email: body.email ?? stored.email, instance_limit: body.instance_limit ?? stored.instance_limit }
+      return { user: { ...stored } }
+    }
+  }))
+  vi.stubGlobal('useAccounts', useAccounts)
+})
+
+afterEach(() => {
+  unmountComponents()
+  vi.unstubAllGlobals()
+})
+
+async function quotaForm(name: 'CreateAccountModal' | 'EditQuotaModal') {
+  const component = Object.assign(loadComponent(`components/accounts/${name}.vue`, {
+    'zod': z,
+    '~/utils/accountQuota': { parseQuota }
+  }), { components: { UForm: primitive('UForm') } })
+  return await mountComponent(component, { target: stored, open: true })
+}
+
+type MountedForm = Awaited<ReturnType<typeof quotaForm>>
+
+async function submit(form: MountedForm) {
+  const target = form.findAll('UForm')[0]!
+  const schema = target.props.schema as z.ZodType<Record<string, unknown>>
+  const result = schema.safeParse(target.props.state)
+  if (result.success) await form.trigger(target, 'onSubmit', { data: result.data })
+  return result
+}
+
+async function fillCreation(form: MountedForm, quota: string | number | undefined) {
+  const inputs = form.findAll('UInput')
+  await form.trigger(inputs[0]!, 'onUpdate:modelValue', ' quota@example.com ')
+  await form.trigger(inputs[1]!, 'onUpdate:modelValue', 'test-password')
+  await form.trigger(inputs[2]!, 'onUpdate:modelValue', quota)
+}
+
+describe('account creation quota', () => {
+  it.each([undefined, '', '   '])('leaves a blank quota %j out of the API body', async (quota) => {
+    const form = await quotaForm('CreateAccountModal')
+    await fillCreation(form, quota)
+    const result = await submit(form)
+    expect(result.success).toBe(true)
+    expect(requests).toEqual([
+      { path: '/users', method: 'POST', body: { email: 'quota@example.com', password: 'test-password', role: 'user' } }
+    ])
+    expect(stored.instance_limit).toBe(4)
+  })
+
+  it.each([[0, 0], ['0', 0], [2, 2], ['2', 2]])('sends quota %j as the number %j', async (quota, expected) => {
+    const form = await quotaForm('CreateAccountModal')
+    await fillCreation(form, quota)
+    const result = await submit(form)
+    expect(result.success).toBe(true)
+    expect(requests).toEqual([
+      { path: '/users', method: 'POST', body: { email: 'quota@example.com', password: 'test-password', role: 'user', instance_limit: expected } }
+    ])
+    expect(stored.instance_limit).toBe(expected)
+    expect(notices).toEqual([expect.objectContaining({ title: translate('accounts.create.createdToast'), color: 'success' })])
+  })
+
+  it.each([-1, '-1', 1.5, '1.5', NaN, Infinity, 'Infinity', 'quota'])('rejects quota %j with the account guidance before sending', async (quota) => {
+    const form = await quotaForm('CreateAccountModal')
+    await fillCreation(form, quota)
+    const result = await submit(form)
+    expect(result.success).toBe(false)
+    if (!result.success) {
+      expect(result.error.issues.map(issue => ({ path: issue.path, message: issue.message }))).toEqual([
+        { path: ['instance_limit'], message: translate('accounts.create.quotaInvalid') }
+      ])
+    }
+    expect(requests).toHaveLength(0)
+    expect(notices).toHaveLength(0)
+  })
+
+  it('keeps the entered fields when the server rejects a duplicate email', async () => {
+    serverError = new ApiError(409, 'conflict', 'Duplicate email')
+    const form = await quotaForm('CreateAccountModal')
+    await fillCreation(form, 2)
+    expect((await submit(form)).success).toBe(true)
+    expect(form.findAll('UAlert').map(alert => alert.props.title)).toEqual([translate('accounts.create.emailTaken')])
+    expect(form.findAll('UInput')[2]!.props.modelValue).toBe(2)
+    expect(notices).toHaveLength(0)
+  })
+})
+
+describe('editing an account quota', () => {
+  it.each([[0, 0], ['0', 0], [3, 3], ['3', 3]])('sends quota %j as the number %j', async (quota, expected) => {
+    const form = await quotaForm('EditQuotaModal')
+    await form.trigger(form.findAll('UInput')[0]!, 'onUpdate:modelValue', quota)
+    const result = await submit(form)
+    expect(result.success).toBe(true)
+    expect(requests).toEqual([
+      { path: `/users/${accountId}`, method: 'PATCH', body: { instance_limit: expected } }
+    ])
+    expect(stored.instance_limit).toBe(expected)
+    expect(notices).toEqual([expect.objectContaining({ title: translate('accounts.quota.updated'), color: 'success' })])
+  })
+
+  it.each([undefined, '', '   ', -1, '-1', 1.5, '1.5', NaN, Infinity, 'Infinity', 'quota'])('requires a valid quota for %j before sending', async (quota) => {
+    const form = await quotaForm('EditQuotaModal')
+    await form.trigger(form.findAll('UInput')[0]!, 'onUpdate:modelValue', quota)
+    const result = await submit(form)
+    expect(result.success).toBe(false)
+    if (!result.success) {
+      expect(result.error.issues.map(issue => ({ path: issue.path, message: issue.message }))).toEqual([
+        { path: ['instance_limit'], message: translate('accounts.quota.quotaInvalid') }
+      ])
+    }
+    expect(requests).toHaveLength(0)
+    expect(stored.instance_limit).toBe(4)
+    expect(notices).toHaveLength(0)
+  })
+
+  it('keeps the entered quota and server error when saving fails', async () => {
+    serverError = new ApiError(422, 'unprocessable_entity', 'Quota could not be saved')
+    const form = await quotaForm('EditQuotaModal')
+    await form.trigger(form.findAll('UInput')[0]!, 'onUpdate:modelValue', 3)
+    expect((await submit(form)).success).toBe(true)
+    expect(form.findAll('UAlert').map(alert => alert.props.title)).toEqual(['Quota could not be saved'])
+    expect(form.findAll('UInput')[0]!.props.modelValue).toBe(3)
+    expect(notices).toHaveLength(0)
+  })
+})
--- a/manager/app/components/auth/LoginForm.test.ts
+++ b/manager/app/components/auth/LoginForm.test.ts
@@ -0,0 +1,109 @@
+import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
+import { ref } from 'vue'
+import * as z from 'zod'
+import { ApiError } from '../../composables/useApi'
+import { useAuth } from '../../composables/useAuth'
+import {
+  installComponentGlobals, loadComponent, mountComponent, primitive, translate, unmountComponents
+} from '../../../tests/componentHarness'
+
+let requests: { path: string, method?: string, body?: unknown }[]
+let serverError: Error | null
+let navigations: { path: string, options?: unknown }[]
+
+beforeEach(() => {
+  installComponentGlobals()
+  requests = []
+  serverError = null
+  navigations = []
+  const states = new Map()
+  vi.stubGlobal('useState', (key: string, initial: () => unknown) => {
+    if (!states.has(key)) states.set(key, ref(initial()))
+    return states.get(key)
+  })
+  vi.stubGlobal('useApi', () => ({
+    api: async (path: string, options?: { method: string, body?: unknown }) => {
+      requests.push({ path, ...options })
+      if (serverError) throw serverError
+      return { me: { id: '42b4c925-dcba-455c-9669-296143778321', email: 'admin@example.com', role: 'admin' } }
+    }
+  }))
+  vi.stubGlobal('useAuth', useAuth)
+  vi.stubGlobal('navigateTo', async (path: string, options?: unknown) => {
+    navigations.push({ path, options })
+  })
+})
+
+afterEach(() => {
+  unmountComponents()
+  vi.unstubAllGlobals()
+})
+
+async function loginForm() {
+  const component = Object.assign(loadComponent('components/auth/LoginForm.vue', { zod: z }), {
+    components: { UAuthForm: primitive('UAuthForm') }
+  })
+  return await mountComponent(component)
+}
+
+type MountedForm = Awaited<ReturnType<typeof loginForm>>
+
+async function submit(form: MountedForm, data?: Record<string, unknown>) {
+  const target = form.findAll('UAuthForm')[0]!
+  const fields = target.props.fields as { name: string, defaultValue?: unknown }[]
+  const untouched = Object.fromEntries(fields.map(field => [field.name, field.defaultValue]))
+  const schema = target.props.schema as z.ZodType<Record<string, unknown>>
+  const result = schema.safeParse(data ?? untouched)
+  if (result.success) await form.trigger(target, 'onSubmit', { data: result.data })
+  return result
+}
+
+describe('login validation', () => {
+  it.each([undefined, { email: '', password: '' }])('explains missing fields for %j without a login request', async (data) => {
+    const form = await loginForm()
+    const result = await submit(form, data)
+    expect(result.success).toBe(false)
+    if (!result.success) {
+      expect(result.error.issues.map(issue => ({ path: issue.path, message: issue.message }))).toEqual([
+        { path: ['email'], message: translate('auth.emailRequired') },
+        { path: ['password'], message: translate('auth.passwordRequired') }
+      ])
+    }
+    expect(requests).toHaveLength(0)
+  })
+
+  it('guides an invalid email without sending credentials', async () => {
+    const form = await loginForm()
+    const result = await submit(form, { email: 'invalid-email', password: 'test-password' })
+    expect(result.success).toBe(false)
+    if (!result.success) {
+      expect(result.error.issues.map(issue => ({ path: issue.path, message: issue.message }))).toEqual([
+        { path: ['email'], message: translate('auth.emailInvalid') }
+      ])
+    }
+    expect(requests).toHaveLength(0)
+  })
+
+  it('accepts the existing one-character password minimum and completes login', async () => {
+    const form = await loginForm()
+    expect((await submit(form, { email: 'admin@example.com', password: 'x' })).success).toBe(true)
+    expect(requests).toEqual([
+      { path: '/auth/login', method: 'POST', body: { email: 'admin@example.com', password: 'x' } }
+    ])
+    expect(navigations).toEqual([{ path: '/', options: undefined }])
+    expect(form.findAll('UAlert')).toHaveLength(0)
+  })
+
+  it.each([
+    [new ApiError(401, 'unauthorized', 'Credentials were rejected'), 'Credentials were rejected'],
+    [new ApiError(401, 'unauthorized', ''), translate('auth.loginFailed')],
+    [new Error('Offline'), translate('auth.serviceUnavailable')]
+  ])('preserves sign-in failure guidance for %j', async (error, expected) => {
+    serverError = error as Error
+    const form = await loginForm()
+    expect((await submit(form, { email: 'admin@example.com', password: 'test-password' })).success).toBe(true)
+    expect(form.findAll('UAlert').map(alert => alert.props.title)).toEqual([expected])
+    expect(navigations).toHaveLength(0)
+    expect(form.findAll('UAuthForm')[0]!.props.submit).toEqual(expect.objectContaining({ loading: false }))
+  })
+})
--- a/manager/app/components/auth/LoginForm.vue
+++ b/manager/app/components/auth/LoginForm.vue
@@ -24,18 +24,20 @@
 import { ApiError } from '~/composables/useApi'
 
 const { t } = useI18n()
 const { login } = useAuth()
 const pending = ref(false)
 const failure = ref<string | null>(null)
 
 const schema = z.object({
-  email: z.email(),
-  password: z.string().min(1)
+  email: z.email({
+    error: issue => issue.input === undefined || issue.input === '' ? t('auth.emailRequired') : t('auth.emailInvalid')
+  }),
+  password: z.string({ error: t('auth.passwordRequired') }).min(1, t('auth.passwordRequired'))
 })
 type Schema = z.output<typeof schema>
 
 const fields = computed(() => [
   { name: 'email', type: 'email' as const, label: t('auth.email'), placeholder: 'admin@example.com', required: true, autocomplete: 'username' },
   { name: 'password', type: 'password' as const, label: t('auth.password'), required: true, autocomplete: 'current-password' }
 ])
 
--- a/manager/app/utils/accountQuota.test.ts
+++ b/manager/app/utils/accountQuota.test.ts
@@ -0,0 +1,21 @@
+import { describe, expect, it } from 'vitest'
+import { parseQuota } from './accountQuota'
+
+describe('quota input parsing', () => {
+  it.each([
+    [undefined, undefined],
+    ['', undefined],
+    ['   ', undefined],
+    [0, 0],
+    ['0', 0],
+    [2, 2],
+    ['2', 2],
+    [' 3 ', 3]
+  ])('normalizes %j to %j while keeping the default distinct from unlimited', (input, expected) => {
+    expect(parseQuota(input)).toBe(expected)
+  })
+
+  it.each([-1, '-1', 1.5, '1.5', NaN, 'NaN', Infinity, 'Infinity', -Infinity, 'quota'])('rejects %j', (input) => {
+    expect(parseQuota(input)).toBeNull()
+  })
+})
--- a/manager/app/utils/accountQuota.ts
+++ b/manager/app/utils/accountQuota.ts
@@ -1,13 +1,13 @@
 // Empty stays omitted so the server default applies; 0 is a valid explicit
 // value meaning unlimited.
-export function parseQuota(raw: string): number | undefined | null {
-  const trimmed = raw.trim()
-  if (trimmed === '') {
+export function parseQuota(raw: string | number | undefined): number | undefined | null {
+  const value = typeof raw === 'string' ? raw.trim() : raw
+  if (value === undefined || value === '') {
     return undefined
   }
-  const parsed = Number(trimmed)
+  const parsed = Number(value)
   if (!Number.isInteger(parsed) || parsed < 0) {
     return null
   }
   return parsed
 }
--- a/manager/i18n/locales/en.json
+++ b/manager/i18n/locales/en.json
@@ -12,16 +12,19 @@
     "noNotifications": "No notifications yet.",
     "searchPlaceholder": "Search actions and pages..."
   },
   "auth": {
     "loginTitle": "Sign in to wzap",
     "loginSubtitle": "Use your manager account to continue.",
     "email": "Email",
     "password": "Password",
+    "emailRequired": "Enter your email.",
+    "emailInvalid": "Enter a valid email address.",
+    "passwordRequired": "Enter your password.",
     "submit": "Sign in",
     "signingIn": "Signing in...",
     "loginFailed": "Sign in failed. Check your email and password.",
     "serviceUnavailable": "Could not reach the service. Check your connection and try again.",
     "sessionExpired": "Your session expired. Sign in again."
   },
   "userMenu": {
     "account": "Account",
@@ -179,16 +182,17 @@
       "failed": "Could not create the instance.",
       "quotaExceeded": "Instance quota exceeded. Nothing was created.",
       "externalRefTaken": "This external reference is already in use.",
       "successTitle": "Instance created",
       "successBody": "Copy the API key now. It will never be shown again.",
       "createdToast": "Instance created as disconnected."
     },
     "detail": {
+      "back": "Back to instances",
       "loadFailed": "Could not load the instance.",
       "notFound": "Instance not found.",
       "saved": "Instance updated.",
       "saveFailed": "Could not save the instance.",
       "externalRefTaken": "This external reference is already in use.",
       "disconnect": "Disconnect",
       "disconnecting": "Disconnecting...",
       "disconnectConfirmTitle": "Disconnect instance",
@@ -337,16 +341,17 @@
       "type": "Type",
       "lastError": "Last error",
       "attempts": "Attempts",
       "createdAt": "Created",
       "deliveredAt": "Delivered",
       "readAt": "Read"
     },
     "sections": {
+      "label": "Instance section",
       "overview": "Overview",
       "messages": "Messages",
       "groups": "Groups",
       "channels": "Channels",
       "profile": "Profile",
       "integrations": "Integrations",
       "settings": "Settings"
     },
```

### Task 3: Manager (tasks 3.1–3.5)

**Ownership:** manager/app e manager/tests, testes/config necessários dentro manager; nenhuma alteração Go ou novas deps.
**Files:** components/instances/{ProfileCard,MessageComposer,ChannelsCard}.vue, pages/instances/[id].vue, components/instances/detail/InstanceSettingsSection.vue, composables de produção relevantes, i18n/locales/en.json e testes que exercitem os fluxos.
**Interfaces:** PATCH profile com campos dirty, mantendo name+status_text verdadeiramente alterados com 501 atômico e aviso; recado-only nunca inclui name. GETs/reloads usam UUID carregado após alias; router.replace mantém query section.

- [ ] RED 3.1: executar fluxo real ProfileCard com name igual e recado alterado/limpo, esperar request apenas status_text e sucesso; ambos alterados preservam 501 e aviso sem descarte/sucesso parcial; foto 501 permanece.
- [ ] GREEN 3.1: patch de campos alterados e validação só das entradas presentes, recado `""` explícito; nome/recado carregados opcionais com defaults adequados.
- [ ] RED 3.2: entry OldName -> rename NewName -> ação/refresh chama UUID e URL válida com section conservada; mudança para outra instância não reutiliza UUID anterior.
- [ ] GREEN 3.2: canonicalização apenas necessária e loader usa identidade carregada da instância correta.
- [ ] RED 3.3: latitude/longitude vazias, whitespace ou só uma ausente não chama sendLocation; `"0"/"0"` é aceito; bounds continuam validados.
- [ ] GREEN 3.3: checar presença antes de Number, manter false/zero legítimos.
- [ ] RED 3.4: imagem/vídeo sem legenda conserva linha+Delete e identificação; texto/legenda continuam visíveis e empty só para coleção vazia.
- [ ] GREEN 3.4: condicionar conteúdo textual, não a linha completa; copy em en.json se necessária.
- [ ] RED 3.5: admin com cache ausente/storage indisponível/freshKey pode revogar; confirmação obrigatória, sucesso limpa cache/one-time key, falha preserva estado e user comum não vê ações.
- [ ] GREEN 3.5: gating pelo escopo autorizado e estado de operação, não pelo localStorage.
- [ ] Verificar `pnpm --dir manager test`, `node --test manager/tests/instanceName.test.mjs`, lint, typecheck e build; usar harness de componente com dependências existentes, sem testes que só copiem expressões da implementação.


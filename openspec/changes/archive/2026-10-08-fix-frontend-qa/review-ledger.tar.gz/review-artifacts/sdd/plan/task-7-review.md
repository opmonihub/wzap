# Task 7 / ISSUE-009 independent review

Spec compliance verdict: **PASS for the scoped implementation**.

Code quality verdict: **PASS**. **No P1/P2 blockers found.** Previous review verdicts stand; this review covers only the native instances-table row-semantics correction.

## Scope and evidence

Read task-7-review-package.md, task-7-report.md and the three assigned sources: InstancesTable.vue, tableRowNavigation.ts and tableRowNavigation.test.ts. Confirmed the relevant installed Table rendering/exposure and current checkbox, name-link, status-action and dropdown callers. No browser/session, full suite, build, dependencies, commits or production-source edits.

- **Native row semantics:** `manager/app/components/instances/InstancesTable.vue:286` binds a root click listener and no longer supplies onSelect. Installed `manager/node_modules/@nuxt/ui/dist/runtime/components/Table.vue:321`/`:322` add button role/tabindex only when onSelect is present, so these rows retain native table semantics. Its onRowSelect immediately returns without onSelect (`:257`–`:260`), leaving the delegated click available. The listener is forwarded through the root's `$attrs` at `:489`.
- **Exposed API is real:** `InstancesTable.vue:64` reads the exposed tableRef and tableApi. Installed Table exposes both at `Table.vue:305`–`:310`; the tableRef belongs to the actual table element at `:369`. Vue component exposure unwraps the ref for the caller.
- **Filtered/sorted/paginated identity:** `InstancesTable.vue:219` passes `tableApi.getRowModel().rows`, not loaded items or a pre-pagination model. Installed Table derives rows from that same final model at `Table.vue:224`, uses it for centerRows when there are no pinned rows at `:227`, and renders centerRows at `:430`. The current caller has no pinning, expansion, virtualization or body-slot insertion. The separator row is in the header at `:404`, so it does not offset `tbody.rows`. The supplied pagination model is installed by `manager/app/composables/useInstancesTable.ts:54`. Under this current configuration, DOM body-row index maps to the correct final displayed row.
- **Ownership and empty states:** `manager/app/utils/tableRowNavigation.ts:12`–`:16` requires the nearest row to be a direct child of this table's first body and the nearest table to be this exact table. Header/outside/nested/foreign rows therefore cannot resolve. An empty-state body row has no corresponding displayed model entry and returns undefined. Missing table refs safely return at `:7`.
- **Native controls:** `tableRowNavigation.ts:10` excludes native links/buttons/inputs/selects/textareas/labels and the current role-based checkbox/menu controls, including descendants resolved through closest. It does not prevent defaults or stop propagation. Name links keep their existing native route and focus treatment (`InstancesTable.vue:328`–`:334`); header and row checkboxes retain their selection handlers (`:288`–`:301`); status and dropdown action wiring remains at `:337`–`:347`. The existing inline Connect/QR controls also stop clicks themselves. Prevented and non-primary clicks are rejected at helper line 7. Modifier/native link behavior is retained because all anchor clicks are excluded.
- **Keyboard behavior:** removing focusable button roles from rows leaves the existing name links, checkboxes and action buttons as keyboard targets. Pointer clicks on noninteractive cells remain a navigation enhancement. No synthetic row key handling or DOM-role rewriting is introduced.

## Test quality and verification

Ran:

```sh
pnpm --config.verify-deps-before-run=false --dir manager test app/utils/tableRowNavigation.test.ts
```

Exit **0**: **1 file, 7/7 tests passed**.

The tests import and execute the production resolver. They verify displayed-row indexing, a filtered-page input, interactive rejection, header/outside rejection, empty-model behavior, table ownership, and prevented/non-primary events. The fixture supplies only DOM lookup boundaries rather than duplicating the resolver. These are useful unit checks, but the titles about sorting/filtering refer to an already prepared displayed model: the tests do not execute TanStack sorting/pagination or mount the SFC. Source inspection establishes that the SFC passes the right model. The generic closest stub also does not validate individual CSS selector matching; actual link/checkbox/button descendant clicks remain browser checks.

## Explicit limits and remaining acceptance

No browser accessibility result is claimed here. The coordinator must confirm native row/cell roles and no nested-interactive finding, pointer navigation after sorting/filtering/pagination, native name-link and modified-link behavior, checkbox selection without navigation, dropdown/Connect actions without accidental navigation, keyboard access through existing controls, and empty/filter-empty states. Full gates and the final build remain coordinator-owned.

The row-index mapping is intentionally tied to the current unpinned, unexpanded, nonvirtualized table without extra body rows. It is valid for this scope; introducing those features later would require revisiting the mapping. No future-feature work is requested by this review.

Only this review artifact was authored. No implementation revision requested.

# Tasks 8 and 9 independent scoped review

Task 8 spec/quality verdict: **PASS after the reviewed filename-alt correction**.

Task 9 spec/quality verdict: **PASS**.

**No remaining P1/P2 blockers found.** Previous independent review verdicts stand. Full gates and actual browser acceptance remain coordinator-owned.

## Scope

Reviewed task-8-report.md, task-9-report.md, updated Task 8 plan/spec scope, shared FileUploadPreview.vue, the five new imports/file-leading slots, the narrowly approved componentHarness.ts additions, and the single light muted-text alias. Used only the relevant portions of current-review-package.md. Confirmed the installed FileUpload/Avatar/slot/theme and VueUse object URL implementations. No broad repeat review, browser/session, build, dependencies, child agents, commits or production-source edits.

## Task 8: preview semantics and lifecycle

- **Review correction resolved:** the first version used empty alt with a claim that an adjacent filename identified the decorative image. Installed FileUpload defaults to layout grid (`manager/node_modules/@nuxt/ui/dist/runtime/components/FileUpload.vue:29`), and the generated grid theme hides fileWrapper (`manager/.nuxt/ui/file-upload.ts:105`). Thus that filename is not visible/announced in these current callers. The coordinator directed the writer to preserve grid layout and use the selected filename as image alt. Re-read final `manager/app/components/shared/FileUploadPreview.vue:12`–`:16`: the comment is corrected and `:alt="file.name"` is present. The implementation report now describes this actual behavior. No visible-filename layout expansion is required by this scope.
- **Actual native image target:** FileUploadPreview uses `:as="{ img: 'img' }"` at `:14`. Installed Avatar forwards alt directly to its selected image component (`manager/node_modules/@nuxt/ui/dist/runtime/components/Avatar.vue:73`–`:83`), so file.name reaches the native img. The alt identifies which file the user selected; it does not claim to describe the image contents.
- **Correct slot and retained styling:** installed FileUpload declares the file-leading slot with file/index/ui (`FileUpload.vue.d.ts:149`) and renders it at `FileUpload.vue:159`. The callers use that supported slot and pass `ui.fileLeadingAvatar()` into the shared component: ProfileCard.vue:142, GroupDetail.vue:320, ChannelsCard.vue:255, MessageComposer.vue:303 and TestSendCard.vue:548. Class fallthrough to the single UAvatar root is consumed by Avatar's class prop/rootClass, preserving generated preview styling, including grid size-full/rounded-lg. Current callers have no custom FileUpload sizes, fileIcon/fileImage values or fileLeadingAvatar overrides; Avatar and FileUpload themes both default to md. Default size is therefore retained for this scope.
- **Object URL lifecycle:** `FileUploadPreview.vue:8` supplies a reactive getter for props.file to the installed `useObjectUrl`. `manager/node_modules/@vueuse/core/dist/index.js:5608` watches the actual file; `:5604`–`:5610` revokes the previous URL before creating a replacement and `:5612` registers scope disposal cleanup. Replacement with the same filename still changes the File object and updates the URL even if FileUpload reuses the keyed preview component. Removal/unmount disposes the final URL.
- **Non-image behavior:** the existing FileUpload default attempts a blob image for any selected file (`FileUpload.vue:90`–`:93`). The shared component retains that behavior and the existing configured file-icon fallback (`FileUploadPreview.vue:17`). Installed Avatar switches to the icon on image failure (`Avatar.vue:59`, `:75`, `:86`–`:89`) and resets the error when src changes (`:54`), permitting subsequent image reselection.
- **Names/removal and existing handlers:** only file-leading is replaced. The current hidden filename/file-size markup and removal remain owned by FileUpload (`FileUpload.vue:170`–`:203`). Its removal button has a filename-bearing accessible label at `:198`. Picker labels, models, accept filters, outside preview position, native picker keyboard behavior and the TestSendCard update handler are untouched.

## Harness and focused verification

`manager/tests/componentHarness.ts:79` adds exactly the shared visual preview dependency as a primitive. The caller-provided imports spread remains later at `:80`, so tests can override it explicitly; unknown imports still fail through the existing resolver. The FileUpload-specific branch at `:146` invokes file-leading for selected model files only, with file/index and the class callback required by the real caller slot. It leaves other slot handling unchanged. This is an appropriate narrow compatibility extension for existing behavior tests, not a substitute for testing the real preview DOM or lifecycle.

Independent focused command:

```sh
pnpm --config.verify-deps-before-run=false --dir manager test app/components/instances/ProfileCard.test.ts app/components/instances/ChannelsCard.test.ts app/components/instances/MessageComposer.test.ts
```

Exit **0**, **3 files / 28 tests passed**. Existing Vue Suspense informational output only. This run preceded the final alt-only correction, which is deliberately hidden behind the visual primitive in these tests; repeating the same suite would not validate that binding. The final alt correction was directly inspected, and the writer separately reports scoped ESLint passing. These tests continue to verify existing real component handlers/API boundaries, including selected-profile-file behavior; they do not claim native image, CSS, URL disposal or accessibility coverage.

## Task 9: muted neutral contrast

`manager/app/assets/css/main.css:27` adds only `--ui-text-muted: var(--ui-color-neutral-600)` under the already reviewed light-only selector at `:20`. App configuration maps neutral to zinc. The installed light muted alias uses neutral500 and toned text uses neutral600; the fix selects the next existing shade without changing palette definitions, normal text, semantic aliases or dark muted mapping. It also intentionally makes light muted and toned text share a shade.

The Task 9 report's installed-palette calculations predict zinc600 contrast of approximately **7.02:1** against the current elevated avatar surface, **7.73:1** on white and **7.37:1** on the subtle neutral surface. These are **predictions, not browser measurements**. They support the chosen scope and are consistent with the supplied prior rendered zinc500 failure of 4.39:1. Input/textarea/Select placeholders use the separate dimmed token and are not silently changed by this correction.

## Remaining acceptance limits

The coordinator must verify native img alt equals the selected filename, actual preview sizing and removal/reselection in all five pickers, filename-bearing removal names, and non-image fallback. The grid filename wrapper is intentionally still hidden; do not claim adjacent filename visibility. Validate actual light muted contrast on the group fallback and relevant neutral surfaces, and unchanged dark presentation. Browser accessibility scans and fresh final tests/lint/typecheck/build remain required coordinator gates. No runtime or browser success is inferred from the source review alone.

Only this review report was authored. No further implementation revision requested.

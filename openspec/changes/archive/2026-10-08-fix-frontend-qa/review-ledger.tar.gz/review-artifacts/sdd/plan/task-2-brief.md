## Task 2: Label associations and names (1.2)

Files: `manager/app/components/shared/DataTableToolbar.vue` (1.4), `manager/app/components/instances/WebhookCard.vue`, `ProfileCard.vue`, `GroupDetail.vue`, `ChannelsCard.vue`, `MessageComposer.vue`, `TestSendCard.vue`, `detail/InstanceSettingsSection.vue`, related focused tests only if they verify behavior rather than copying implementation.

1. Inspect installed Nuxt UI Checkbox/FileUpload/Select injection and attribute forwarding.
2. Give every event checkbox a unique component-scoped id that targets its own label; preserve subscription order, All/None, enabled and URL logic.
3. Add locale-backed accessible names to the actual role-button file upload pickers and the confirmed Groups participants action, Channels status media type and Settings default disappearing selectors.
4. Use existing copy; tell controller any new keys. Check all visible file picker locations in the listed files. Do not change the instance page or section navigation.
5. ISSUE-008: all instance columns are required, so its Display menu is empty; hide the shared column-display dropdown when the provided optional-column list is empty, while keeping Accounts display/toggling working. Do not unlock required instance columns. Browser before evidence is screenshots/30-instance-display-empty-menu.png; verify both tables after build.
6. Use browser pre-fix evidence as the failing accessibility regression for simple attribute changes; focused meaningful webhook tests should cover subscription changes/save payload. The controller then clicks actual labels and checks actual accessible names in the built browser.


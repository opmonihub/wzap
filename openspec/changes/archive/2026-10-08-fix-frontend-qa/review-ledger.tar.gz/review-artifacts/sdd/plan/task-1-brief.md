## Task 1: Forms (1.1)

Files: `manager/app/utils/accountQuota.ts`, `manager/app/components/accounts/{CreateAccountModal,EditQuotaModal}.vue`, `manager/app/components/auth/LoginForm.vue` and focused tests in those same directories. Read this worktree's AGENTS files, debugging/TDD skills and existing component harness.

1. Reproduce current numeric failures using the shared parser and compiled real form schemas/components; log a failing regression before fixing.
2. Accept the actual number/string/undefined numeric input model; empty creation stays omitted, explicit 0 stays 0, positive integers stay numeric; reject negative, fractional, non-finite and invalid text values. Editing remains required.
3. Make untouched login email/password display the existing auth validation copy, including when the model is undefined; preserve invalid-email/min-password and server-error behavior.
4. Run focused Vitest and self-review. Report exact file/line root causes, red and green commands/results, remaining concerns and needed locale keys.


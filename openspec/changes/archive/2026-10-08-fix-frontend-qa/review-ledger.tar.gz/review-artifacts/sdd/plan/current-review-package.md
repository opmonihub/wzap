# New frontend QA deltas only

Baseline: snapshot of dirty manager taken before this QA correction round. Preserve all earlier changes.

Files:
- manager/app/app.config.ts
- manager/app/assets/css/main.css
- manager/app/components/accounts/CreateAccountModal.vue
- manager/app/components/accounts/EditQuotaModal.vue
- manager/app/components/accounts/QuotaForms.test.ts
- manager/app/components/auth/LoginForm.test.ts
- manager/app/components/auth/LoginForm.vue
- manager/app/components/instances/ChannelsCard.vue
- manager/app/components/instances/GroupDetail.vue
- manager/app/components/instances/InstancesTable.vue
- manager/app/components/instances/MessageComposer.vue
- manager/app/components/instances/ProfileCard.vue
- manager/app/components/instances/TestSendCard.vue
- manager/app/components/instances/WebhookCard.test.ts
- manager/app/components/instances/WebhookCard.vue
- manager/app/components/instances/detail/InstanceSectionNav.test.ts
- manager/app/components/instances/detail/InstanceSectionNav.vue
- manager/app/components/instances/detail/InstanceSettingsSection.vue
- manager/app/components/shared/DataTableToolbar.vue
- manager/app/components/shared/FileUploadPreview.vue
- manager/app/pages/instances/[id].vue
- manager/app/utils/accountQuota.test.ts
- manager/app/utils/accountQuota.ts
- manager/app/utils/tableRowNavigation.test.ts
- manager/app/utils/tableRowNavigation.ts
- manager/i18n/locales/en.json
- manager/tests/componentHarness.ts

```diff
--- a/manager/app/app.config.ts
+++ b/manager/app/app.config.ts
@@ -1,8 +1,27 @@
 export default defineAppConfig({
   ui: {
     colors: {
       primary: 'green',
       neutral: 'zinc'
+    },
+    button: {
+      compoundVariants: [
+        {
+          color: 'primary',
+          variant: 'solid',
+          class: 'hover:bg-primary-900 active:bg-primary-900 dark:hover:bg-primary/75 dark:active:bg-primary/75'
+        },
+        {
+          color: 'error',
+          variant: 'solid',
+          class: 'dark:hover:bg-error/90 dark:active:bg-error/90'
+        },
+        {
+          color: 'error',
+          variant: 'soft',
+          class: 'dark:hover:bg-error/10 dark:active:bg-error/10'
+        }
+      ]
     }
   }
 })
--- a/manager/app/assets/css/main.css
+++ b/manager/app/assets/css/main.css
@@ -11,8 +11,18 @@
   --color-green-400: #00DC82;
   --color-green-500: #00C16A;
   --color-green-600: #00A155;
   --color-green-700: #007F45;
   --color-green-800: #016538;
   --color-green-900: #0A5331;
   --color-green-950: #052E16;
 }
+
+:root:not(.dark),
+.light {
+  --ui-primary: var(--ui-color-primary-800);
+  --ui-success: var(--ui-color-success-800);
+  --ui-info: var(--ui-color-info-700);
+  --ui-warning: var(--ui-color-warning-800);
+  --ui-error: var(--ui-color-error-800);
+  --ui-text-muted: var(--ui-color-neutral-600);
+}
--- a/manager/app/components/accounts/CreateAccountModal.vue
+++ b/manager/app/components/accounts/CreateAccountModal.vue
@@ -13,17 +13,19 @@
 const { t } = useI18n()
 const toast = useToast()
 const { createUser } = useAccounts()
 
 const createSchema = z.object({
   email: z.string().min(1, t('accounts.create.emailRequired')).max(255),
   password: z.string().min(1, t('accounts.create.passwordRequired')),
   role: z.enum(['admin', 'user']),
-  instance_limit: z.string()
+  instance_limit: z.union([z.string(), z.number()], { error: t('accounts.create.quotaInvalid') })
+    .optional()
+    .refine(value => parseQuota(value) !== null, t('accounts.create.quotaInvalid'))
 })
 type CreateSchema = z.output<typeof createSchema>
 const createState = reactive<Partial<CreateSchema>>({ email: '', password: '', role: 'user', instance_limit: '' })
 const creating = ref(false)
 const createFailure = ref<string | null>(null)
 
 function resetCreate() {
   createState.email = ''
--- a/manager/app/components/accounts/EditQuotaModal.vue
+++ b/manager/app/components/accounts/EditQuotaModal.vue
@@ -13,17 +13,22 @@
 }>()
 const open = defineModel<boolean>('open', { default: false })
 
 const { t } = useI18n()
 const toast = useToast()
 const { updateUserQuota } = useAccounts()
 
 const quotaSchema = z.object({
-  instance_limit: z.string()
+  instance_limit: z.union([z.string(), z.number()], { error: t('accounts.quota.quotaInvalid') })
+    .optional()
+    .refine((value) => {
+      const quota = parseQuota(value)
+      return quota !== null && quota !== undefined
+    }, t('accounts.quota.quotaInvalid'))
 })
 type QuotaSchema = z.output<typeof quotaSchema>
 const quotaState = reactive<Partial<QuotaSchema>>({ instance_limit: '' })
 const quotaSaving = ref(false)
 const quotaFailure = ref<string | null>(null)
 
 watch([open, () => props.target], ([isOpen, target]) => {
   if (isOpen && target) {
--- a/manager/app/components/accounts/QuotaForms.test.ts
+++ b/manager/app/components/accounts/QuotaForms.test.ts
@@ -0,0 +1,160 @@
+import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
+import * as z from 'zod'
+import { ApiError } from '../../composables/useApi'
+import { useAccounts } from '../../composables/useAccounts'
+import type { AccountUser } from '../../types/api'
+import { parseQuota } from '../../utils/accountQuota'
+import {
+  installComponentGlobals, loadComponent, mountComponent, primitive, translate, unmountComponents
+} from '../../../tests/componentHarness'
+
+const accountId = '67a5b146-74e8-4fa5-b77d-dcd92fba7012'
+let stored: AccountUser
+let requests: { path: string, method?: string, body?: unknown }[]
+let notices: { title: string, color: string }[]
+let serverError: Error | null
+
+beforeEach(() => {
+  installComponentGlobals()
+  stored = {
+    id: accountId,
+    email: 'quota@example.com',
+    role: 'user',
+    instance_limit: 4,
+    instances_used: 0,
+    created_at: '2026-10-07T12:00:00Z',
+    updated_at: '2026-10-07T12:00:00Z'
+  }
+  requests = []
+  notices = []
+  serverError = null
+  vi.stubGlobal('useToast', () => ({ add: (notice: typeof notices[number]) => notices.push(notice) }))
+  vi.stubGlobal('useApi', () => ({
+    api: async (path: string, options?: { method: string, body?: unknown }) => {
+      requests.push({ path, ...options })
+      if (serverError) throw serverError
+      const body = options?.body as { email?: string, instance_limit?: number }
+      stored = { ...stored, email: body.email ?? stored.email, instance_limit: body.instance_limit ?? stored.instance_limit }
+      return { user: { ...stored } }
+    }
+  }))
+  vi.stubGlobal('useAccounts', useAccounts)
+})
+
+afterEach(() => {
+  unmountComponents()
+  vi.unstubAllGlobals()
+})
+
+async function quotaForm(name: 'CreateAccountModal' | 'EditQuotaModal') {
+  const component = Object.assign(loadComponent(`components/accounts/${name}.vue`, {
+    'zod': z,
+    '~/utils/accountQuota': { parseQuota }
+  }), { components: { UForm: primitive('UForm') } })
+  return await mountComponent(component, { target: stored, open: true })
+}
+
+type MountedForm = Awaited<ReturnType<typeof quotaForm>>
+
+async function submit(form: MountedForm) {
+  const target = form.findAll('UForm')[0]!
+  const schema = target.props.schema as z.ZodType<Record<string, unknown>>
+  const result = schema.safeParse(target.props.state)
+  if (result.success) await form.trigger(target, 'onSubmit', { data: result.data })
+  return result
+}
+
+async function fillCreation(form: MountedForm, quota: string | number | undefined) {
+  const inputs = form.findAll('UInput')
+  await form.trigger(inputs[0]!, 'onUpdate:modelValue', ' quota@example.com ')
+  await form.trigger(inputs[1]!, 'onUpdate:modelValue', 'test-password')
+  await form.trigger(inputs[2]!, 'onUpdate:modelValue', quota)
+}
+
+describe('account creation quota', () => {
+  it.each([undefined, '', '   '])('leaves a blank quota %j out of the API body', async (quota) => {
+    const form = await quotaForm('CreateAccountModal')
+    await fillCreation(form, quota)
+    const result = await submit(form)
+    expect(result.success).toBe(true)
+    expect(requests).toEqual([
+      { path: '/users', method: 'POST', body: { email: 'quota@example.com', password: 'test-password', role: 'user' } }
+    ])
+    expect(stored.instance_limit).toBe(4)
+  })
+
+  it.each([[0, 0], ['0', 0], [2, 2], ['2', 2]])('sends quota %j as the number %j', async (quota, expected) => {
+    const form = await quotaForm('CreateAccountModal')
+    await fillCreation(form, quota)
+    const result = await submit(form)
+    expect(result.success).toBe(true)
+    expect(requests).toEqual([
+      { path: '/users', method: 'POST', body: { email: 'quota@example.com', password: 'test-password', role: 'user', instance_limit: expected } }
+    ])
+    expect(stored.instance_limit).toBe(expected)
+    expect(notices).toEqual([expect.objectContaining({ title: translate('accounts.create.createdToast'), color: 'success' })])
+  })
+
+  it.each([-1, '-1', 1.5, '1.5', NaN, Infinity, 'Infinity', 'quota'])('rejects quota %j with the account guidance before sending', async (quota) => {
+    const form = await quotaForm('CreateAccountModal')
+    await fillCreation(form, quota)
+    const result = await submit(form)
+    expect(result.success).toBe(false)
+    if (!result.success) {
+      expect(result.error.issues.map(issue => ({ path: issue.path, message: issue.message }))).toEqual([
+        { path: ['instance_limit'], message: translate('accounts.create.quotaInvalid') }
+      ])
+    }
+    expect(requests).toHaveLength(0)
+    expect(notices).toHaveLength(0)
+  })
+
+  it('keeps the entered fields when the server rejects a duplicate email', async () => {
+    serverError = new ApiError(409, 'conflict', 'Duplicate email')
+    const form = await quotaForm('CreateAccountModal')
+    await fillCreation(form, 2)
+    expect((await submit(form)).success).toBe(true)
+    expect(form.findAll('UAlert').map(alert => alert.props.title)).toEqual([translate('accounts.create.emailTaken')])
+    expect(form.findAll('UInput')[2]!.props.modelValue).toBe(2)
+    expect(notices).toHaveLength(0)
+  })
+})
+
+describe('editing an account quota', () => {
+  it.each([[0, 0], ['0', 0], [3, 3], ['3', 3]])('sends quota %j as the number %j', async (quota, expected) => {
+    const form = await quotaForm('EditQuotaModal')
+    await form.trigger(form.findAll('UInput')[0]!, 'onUpdate:modelValue', quota)
+    const result = await submit(form)
+    expect(result.success).toBe(true)
+    expect(requests).toEqual([
+      { path: `/users/${accountId}`, method: 'PATCH', body: { instance_limit: expected } }
+    ])
+    expect(stored.instance_limit).toBe(expected)
+    expect(notices).toEqual([expect.objectContaining({ title: translate('accounts.quota.updated'), color: 'success' })])
+  })
+
+  it.each([undefined, '', '   ', -1, '-1', 1.5, '1.5', NaN, Infinity, 'Infinity', 'quota'])('requires a valid quota for %j before sending', async (quota) => {
+    const form = await quotaForm('EditQuotaModal')
+    await form.trigger(form.findAll('UInput')[0]!, 'onUpdate:modelValue', quota)
+    const result = await submit(form)
+    expect(result.success).toBe(false)
+    if (!result.success) {
+      expect(result.error.issues.map(issue => ({ path: issue.path, message: issue.message }))).toEqual([
+        { path: ['instance_limit'], message: translate('accounts.quota.quotaInvalid') }
+      ])
+    }
+    expect(requests).toHaveLength(0)
+    expect(stored.instance_limit).toBe(4)
+    expect(notices).toHaveLength(0)
+  })
+
+  it('keeps the entered quota and server error when saving fails', async () => {
+    serverError = new ApiError(422, 'unprocessable_entity', 'Quota could not be saved')
+    const form = await quotaForm('EditQuotaModal')
+    await form.trigger(form.findAll('UInput')[0]!, 'onUpdate:modelValue', 3)
+    expect((await submit(form)).success).toBe(true)
+    expect(form.findAll('UAlert').map(alert => alert.props.title)).toEqual(['Quota could not be saved'])
+    expect(form.findAll('UInput')[0]!.props.modelValue).toBe(3)
+    expect(notices).toHaveLength(0)
+  })
+})
--- a/manager/app/components/auth/LoginForm.test.ts
+++ b/manager/app/components/auth/LoginForm.test.ts
@@ -0,0 +1,109 @@
+import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
+import { ref } from 'vue'
+import * as z from 'zod'
+import { ApiError } from '../../composables/useApi'
+import { useAuth } from '../../composables/useAuth'
+import {
+  installComponentGlobals, loadComponent, mountComponent, primitive, translate, unmountComponents
+} from '../../../tests/componentHarness'
+
+let requests: { path: string, method?: string, body?: unknown }[]
+let serverError: Error | null
+let navigations: { path: string, options?: unknown }[]
+
+beforeEach(() => {
+  installComponentGlobals()
+  requests = []
+  serverError = null
+  navigations = []
+  const states = new Map()
+  vi.stubGlobal('useState', (key: string, initial: () => unknown) => {
+    if (!states.has(key)) states.set(key, ref(initial()))
+    return states.get(key)
+  })
+  vi.stubGlobal('useApi', () => ({
+    api: async (path: string, options?: { method: string, body?: unknown }) => {
+      requests.push({ path, ...options })
+      if (serverError) throw serverError
+      return { me: { id: '42b4c925-dcba-455c-9669-296143778321', email: 'admin@example.com', role: 'admin' } }
+    }
+  }))
+  vi.stubGlobal('useAuth', useAuth)
+  vi.stubGlobal('navigateTo', async (path: string, options?: unknown) => {
+    navigations.push({ path, options })
+  })
+})
+
+afterEach(() => {
+  unmountComponents()
+  vi.unstubAllGlobals()
+})
+
+async function loginForm() {
+  const component = Object.assign(loadComponent('components/auth/LoginForm.vue', { zod: z }), {
+    components: { UAuthForm: primitive('UAuthForm') }
+  })
+  return await mountComponent(component)
+}
+
+type MountedForm = Awaited<ReturnType<typeof loginForm>>
+
+async function submit(form: MountedForm, data?: Record<string, unknown>) {
+  const target = form.findAll('UAuthForm')[0]!
+  const fields = target.props.fields as { name: string, defaultValue?: unknown }[]
+  const untouched = Object.fromEntries(fields.map(field => [field.name, field.defaultValue]))
+  const schema = target.props.schema as z.ZodType<Record<string, unknown>>
+  const result = schema.safeParse(data ?? untouched)
+  if (result.success) await form.trigger(target, 'onSubmit', { data: result.data })
+  return result
+}
+
+describe('login validation', () => {
+  it.each([undefined, { email: '', password: '' }])('explains missing fields for %j without a login request', async (data) => {
+    const form = await loginForm()
+    const result = await submit(form, data)
+    expect(result.success).toBe(false)
+    if (!result.success) {
+      expect(result.error.issues.map(issue => ({ path: issue.path, message: issue.message }))).toEqual([
+        { path: ['email'], message: translate('auth.emailRequired') },
+        { path: ['password'], message: translate('auth.passwordRequired') }
+      ])
+    }
+    expect(requests).toHaveLength(0)
+  })
+
+  it('guides an invalid email without sending credentials', async () => {
+    const form = await loginForm()
+    const result = await submit(form, { email: 'invalid-email', password: 'test-password' })
+    expect(result.success).toBe(false)
+    if (!result.success) {
+      expect(result.error.issues.map(issue => ({ path: issue.path, message: issue.message }))).toEqual([
+        { path: ['email'], message: translate('auth.emailInvalid') }
+      ])
+    }
+    expect(requests).toHaveLength(0)
+  })
+
+  it('accepts the existing one-character password minimum and completes login', async () => {
+    const form = await loginForm()
+    expect((await submit(form, { email: 'admin@example.com', password: 'x' })).success).toBe(true)
+    expect(requests).toEqual([
+      { path: '/auth/login', method: 'POST', body: { email: 'admin@example.com', password: 'x' } }
+    ])
+    expect(navigations).toEqual([{ path: '/', options: undefined }])
+    expect(form.findAll('UAlert')).toHaveLength(0)
+  })
+
+  it.each([
+    [new ApiError(401, 'unauthorized', 'Credentials were rejected'), 'Credentials were rejected'],
+    [new ApiError(401, 'unauthorized', ''), translate('auth.loginFailed')],
+    [new Error('Offline'), translate('auth.serviceUnavailable')]
+  ])('preserves sign-in failure guidance for %j', async (error, expected) => {
+    serverError = error as Error
+    const form = await loginForm()
+    expect((await submit(form, { email: 'admin@example.com', password: 'test-password' })).success).toBe(true)
+    expect(form.findAll('UAlert').map(alert => alert.props.title)).toEqual([expected])
+    expect(navigations).toHaveLength(0)
+    expect(form.findAll('UAuthForm')[0]!.props.submit).toEqual(expect.objectContaining({ loading: false }))
+  })
+})
--- a/manager/app/components/auth/LoginForm.vue
+++ b/manager/app/components/auth/LoginForm.vue
@@ -24,18 +24,20 @@
 import { ApiError } from '~/composables/useApi'
 
 const { t } = useI18n()
 const { login } = useAuth()
 const pending = ref(false)
 const failure = ref<string | null>(null)
 
 const schema = z.object({
-  email: z.email(),
-  password: z.string().min(1)
+  email: z.email({
+    error: issue => issue.input === undefined || issue.input === '' ? t('auth.emailRequired') : t('auth.emailInvalid')
+  }),
+  password: z.string({ error: t('auth.passwordRequired') }).min(1, t('auth.passwordRequired'))
 })
 type Schema = z.output<typeof schema>
 
 const fields = computed(() => [
   { name: 'email', type: 'email' as const, label: t('auth.email'), placeholder: 'admin@example.com', required: true, autocomplete: 'username' },
   { name: 'password', type: 'password' as const, label: t('auth.password'), required: true, autocomplete: 'current-password' }
 ])
 
--- a/manager/app/components/instances/ChannelsCard.vue
+++ b/manager/app/components/instances/ChannelsCard.vue
@@ -1,9 +1,10 @@
 <script setup lang="ts">
+import FileUploadPreview from '~/components/shared/FileUploadPreview.vue'
 import { ApiError } from '~/composables/useApi'
 import type { InstanceStatus, Newsletter, OwnStatus } from '~/types/api'
 
 // Newsletters (follow/unfollow + lookup + followed list with title/channel +
 // follower count) and own statuses (text publish, image|video media publish
 // fire-and-forget, own list with identity/type and optional text/caption
 // bubbles, delete). Text/caption validate 1..700 characters.
 const props = defineProps<{
@@ -235,21 +236,31 @@
             class="w-fit shrink-0"
             :label="t('instances.channels.publish')"
             @click="onPublish"
           />
         </div>
         <div class="flex min-w-0 flex-col gap-2 sm:flex-row sm:items-center">
           <USelect
             v-model="statusKind"
+            :aria-label="t('instances.channels.statusKind')"
             :items="statusKinds"
             :placeholder="t('instances.channels.statusKind')"
             class="w-full sm:w-32"
           />
-          <UFileUpload v-model="statusFile" accept="image/*,video/*" class="w-full" />
+          <UFileUpload
+            v-model="statusFile"
+            :label="t('instances.send.file')"
+            accept="image/*,video/*"
+            class="w-full"
+          >
+            <template #file-leading="{ file, ui }">
+              <FileUploadPreview :file="file" :class="ui.fileLeadingAvatar()" />
+            </template>
+          </UFileUpload>
           <UInput
             v-model="statusCaption"
             maxlength="700"
             class="w-full"
             :placeholder="t('instances.send.caption')"
           />
           <UButton
             :disabled="!canAct || !statusFile"
--- a/manager/app/components/instances/GroupDetail.vue
+++ b/manager/app/components/instances/GroupDetail.vue
@@ -1,9 +1,10 @@
 <script setup lang="ts">
+import FileUploadPreview from '~/components/shared/FileUploadPreview.vue'
 import { ApiError } from '~/composables/useApi'
 import { groupLookupJIDOrNull } from '~/utils/groupLookup'
 import type { Group, InstanceStatus } from '~/types/api'
 
 // Group lookup/create/join plus the loaded-group detail: rename/description
 // update, invite get/reset, octet-stream photo upload and participant
 // management. A 201 with an empty invite_code reconciles via GET invite and
 // never retries create (retry would duplicate the group).
@@ -306,32 +307,38 @@
             :label="t('instances.groups.copyInvite')"
             @click="onCopyInvite"
           />
         </div>
       </div>
       <div class="flex flex-col gap-2">
         <UFileUpload
           v-model="photoFile"
+          :label="t('instances.groups.photo')"
           accept="image/*"
           :hint="t('instances.groups.photoHint')"
           variant="area"
-        />
+        >
+          <template #file-leading="{ file, ui }">
+            <FileUploadPreview :file="file" :class="ui.fileLeadingAvatar()" />
+          </template>
+        </UFileUpload>
         <div class="flex justify-end">
           <UButton
             :disabled="!canAct || !photoFile"
             variant="soft"
             :label="t('instances.groups.uploadPhoto')"
             @click="onPhoto"
           />
         </div>
       </div>
       <div class="flex flex-col gap-2">
         <USelect
           v-model="participantAction"
+          :aria-label="t('instances.groups.participantsAction')"
           :items="participantActions"
           :placeholder="t('instances.groups.participantsAction')"
           class="w-full"
         />
         <UTextarea
           v-model="participantJids"
           :rows="3"
           :placeholder="t('instances.groups.participants')"
--- a/manager/app/components/instances/InstancesTable.vue
+++ b/manager/app/components/instances/InstancesTable.vue
@@ -1,16 +1,17 @@
 <script setup lang="ts">
 import type { DropdownMenuItem, TableRow } from '@nuxt/ui'
 import { useInstancesTable } from '~/composables/useInstancesTable'
 import InstancesTableActionsCell from '~/components/instances/InstancesTableActionsCell.vue'
 import InstancesTableNameCell from '~/components/instances/InstancesTableNameCell.vue'
 import InstancesTableStatusCell from '~/components/instances/InstancesTableStatusCell.vue'
 import DataTableFooter from '~/components/shared/DataTableFooter.vue'
 import DataTableToolbar from '~/components/shared/DataTableToolbar.vue'
+import { tableRowNavigation } from '~/utils/tableRowNavigation'
 import type { Instance, InstanceStatus } from '~/types/api'
 
 const props = defineProps<{
   items: Instance[]
   isAdmin: boolean
 }>()
 
 const emit = defineEmits<{
@@ -27,16 +28,17 @@
 interface InstancesTableColumn {
   id: string
   getCanHide: () => boolean
   getIsVisible: () => boolean
   toggleVisibility: (visible: boolean) => void
 }
 
 interface InstancesTableApi {
+  getRowModel: () => { rows: TableRow<Instance>[] }
   getFilteredRowModel: () => { rows: TableRow<Instance>[] }
   getFilteredSelectedRowModel: () => { rows: TableRow<Instance>[] }
   setPageIndex: (index: number) => void
   setPageSize: (size: number) => void
   resetRowSelection: () => void
   getAllColumns: () => InstancesTableColumn[]
 }
 
@@ -54,17 +56,17 @@
   columnFilters,
   columnVisibility: visibilityOverrides,
   rowSelection,
   pagination,
   globalFilterOptions,
   paginationOptions
 } = useInstancesTable(itemsRef, isAdminRef)
 
-const table = useTemplateRef<{ tableApi?: InstancesTableApi }>('table')
+const table = useTemplateRef<{ tableApi?: InstancesTableApi, tableRef?: HTMLTableElement }>('table')
 
 // The remodeled public instance hides owner_user_id, external_ref and
 // whatsapp_jid, so only name/status/actions remain: the column-visibility
 // merge stays for the dropdown even though every column is always visible.
 const columnVisibility = computed<Record<string, boolean>>({
   get: () => ({ ...visibilityOverrides.value }),
   set: (next) => {
     visibilityOverrides.value = { ...next }
@@ -205,22 +207,22 @@
 // Row navigation stays inside the table (no open emit): row click and the
 // name link go straight to the detail screen, except when the click lands on
 // an interactive element (links, buttons, inputs, checkboxes, menu items),
 // which keeps its own behavior.
 function openDetails(instance: Instance) {
   void navigateTo(`/instances/${instance.id}`)
 }
 
-function onRowSelect(event: Event, row: { original: Instance }) {
-  const target = event.target as HTMLElement | null
-  if (target?.closest('a, button, input, [role="menuitem"], [role="menuitemcheckbox"]')) {
-    return
-  }
-  openDetails(row.original)
+function onTableClick(event: MouseEvent) {
+  // UTable's onSelect turns native rows into buttons containing controls.
+  // Delegate pointer clicks instead; this unpinned, unexpanded table renders
+  // native body rows in the current filtered/sorted/paginated model order.
+  const row = tableRowNavigation(event, table.value?.tableRef, table.value?.tableApi?.getRowModel().rows ?? [])
+  if (row) openDetails(row.original)
 }
 </script>
 
 <template>
   <div class="flex flex-col gap-3">
     <DataTableToolbar
       v-model:filter="globalFilter"
       :search-placeholder="t('instances.table.search')"
@@ -267,26 +269,26 @@
       v-model:row-selection="rowSelection"
       v-model:pagination="pagination"
       :data="items"
       :columns="columns"
       :global-filter-options="globalFilterOptions"
       :pagination-options="paginationOptions"
       :get-row-id="getRowId"
       :auto-reset-all="false"
-      :on-select="onRowSelect"
       class="shrink-0"
       :ui="{
         base: 'table-fixed border-separate border-spacing-0',
         thead: '[&>tr]:bg-elevated/50 [&>tr]:after:content-none',
         tbody: '[&>tr]:last:[&>td]:border-b-0',
         th: 'py-2 first:rounded-l-lg last:rounded-r-lg border-y border-default first:border-l last:border-r',
         td: 'border-b border-default',
         separator: 'h-0'
       }"
+      @click="onTableClick"
     >
       <template #select-header="{ table: api }">
         <UCheckbox
           :model-value="api.getIsSomePageRowsSelected() ? 'indeterminate' : api.getIsAllPageRowsSelected()"
           :aria-label="t('instances.table.selectAll')"
           @update:model-value="(value: boolean | 'indeterminate') => api.toggleAllPageRowsSelected(!!value)"
         />
       </template>
--- a/manager/app/components/instances/MessageComposer.vue
+++ b/manager/app/components/instances/MessageComposer.vue
@@ -1,9 +1,10 @@
 <script setup lang="ts">
+import FileUploadPreview from '~/components/shared/FileUploadPreview.vue'
 import { ApiError } from '~/composables/useApi'
 import type { InstanceStatus, MediaKind } from '~/types/api'
 
 // Footer reply card for the messages split: shared recipient plus sub-tabs
 // for text/media/location/contact/poll/reaction/list/buttons. Every send mints
 // a fresh Idempotency-Key per click inside the composables; 422 answers
 // surface the server text verbatim. Sends are gated on a connected instance
 // and each accepted message is polled until sent/failed (settled).
@@ -288,17 +289,26 @@
         v-if="tab === 'text'"
         v-model="text"
         variant="none"
         :rows="3"
         :placeholder="t('instances.send.text')"
         class="w-full"
       />
       <div v-else-if="tab === 'media'" class="flex flex-col gap-2">
-        <UFileUpload v-model="mediaFile" accept="image/*,video/*,audio/*,.pdf,.txt,.doc,.docx" variant="area" />
+        <UFileUpload
+          v-model="mediaFile"
+          :label="t('instances.send.file')"
+          accept="image/*,video/*,audio/*,.pdf,.txt,.doc,.docx"
+          variant="area"
+        >
+          <template #file-leading="{ file, ui }">
+            <FileUploadPreview :file="file" :class="ui.fileLeadingAvatar()" />
+          </template>
+        </UFileUpload>
         <UInput v-model="mediaCaption" :placeholder="t('instances.send.caption')" class="w-full" />
       </div>
       <div v-else-if="tab === 'location'" class="flex flex-col gap-2 sm:flex-row">
         <UInput v-model="latitude" :placeholder="t('instances.send.latitude')" class="w-full font-mono" />
         <UInput v-model="longitude" :placeholder="t('instances.send.longitude')" class="w-full font-mono" />
       </div>
       <div v-else-if="tab === 'contact'" class="flex flex-col gap-2">
         <UInput v-model="displayName" :placeholder="t('instances.send.displayName')" class="w-full" />
--- a/manager/app/components/instances/ProfileCard.vue
+++ b/manager/app/components/instances/ProfileCard.vue
@@ -1,9 +1,10 @@
 <script setup lang="ts">
+import FileUploadPreview from '~/components/shared/FileUploadPreview.vue'
 import { ApiError } from '~/composables/useApi'
 import type { InstanceStatus, Profile, UpdateProfileInput } from '~/types/api'
 
 const props = defineProps<{
   instanceId: string
   status: InstanceStatus
 }>()
 
@@ -127,17 +128,26 @@
       </UFormField>
       <UFormField :label="t('instances.profile.recado')" :hint="t('instances.profile.recadoHint')">
         <UInput v-model="recado" maxlength="500" class="w-full" />
       </UFormField>
       <div class="flex justify-end">
         <UButton :disabled="!canAct" :label="t('common.save')" @click="onSave" />
       </div>
       <UFormField :label="t('instances.profile.photo')" :hint="t('instances.profile.photoHint')">
-        <UFileUpload v-model="photoFile" accept="image/*" variant="area" />
+        <UFileUpload
+          v-model="photoFile"
+          :label="t('instances.profile.photo')"
+          accept="image/*"
+          variant="area"
+        >
+          <template #file-leading="{ file, ui }">
+            <FileUploadPreview :file="file" :class="ui.fileLeadingAvatar()" />
+          </template>
+        </UFileUpload>
       </UFormField>
       <div class="flex justify-end">
         <UButton
           :disabled="!canAct || !photoFile"
           variant="soft"
           :label="t('instances.profile.uploadPhoto')"
           @click="onPhoto"
         />
--- a/manager/app/components/instances/TestSendCard.vue
+++ b/manager/app/components/instances/TestSendCard.vue
@@ -1,9 +1,10 @@
 <script setup lang="ts">
+import FileUploadPreview from '~/components/shared/FileUploadPreview.vue'
 import * as z from 'zod'
 import type { FormSubmitEvent } from '#ui/types'
 import { ApiError } from '~/composables/useApi'
 import MessageDetail from '~/components/instances/MessageDetail.vue'
 import type { InstanceStatus, MediaKind, NumberCheckResult, OutboundMessage } from '~/types/api'
 
 // Test-send card for one instance: number check (numbers/check, which never
 // enqueues), text send and multipart media send (202 with a queued id), plus
@@ -534,20 +535,25 @@
         <UFormField
           :label="t('instances.send.file')"
           :hint="t('instances.send.fileHint')"
           name="media_file"
           required
         >
           <UFileUpload
             v-model="mediaFile"
+            :label="t('instances.send.file')"
             accept="image/*,video/*,audio/*,.pdf,.doc,.docx"
             variant="area"
             @update:model-value="onFileChange"
-          />
+          >
+            <template #file-leading="{ file, ui }">
+              <FileUploadPreview :file="file" :class="ui.fileLeadingAvatar()" />
+            </template>
+          </UFileUpload>
         </UFormField>
         <p v-if="mediaKind" class="font-mono text-sm text-muted">
           {{ mediaName }} — {{ t('instances.send.detectedKind', { kind: mediaKind }) }}
         </p>
         <UFormField :label="t('instances.send.caption')" name="media_caption">
           <UInput v-model="mediaState.media_caption" maxlength="1024" class="w-full" />
         </UFormField>
         <UFormField :label="t('instances.send.filename')" :hint="t('instances.send.filenameHint')" name="media_filename">
--- a/manager/app/components/instances/WebhookCard.test.ts
+++ b/manager/app/components/instances/WebhookCard.test.ts
@@ -0,0 +1,73 @@
+import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
+import * as z from 'zod'
+import { WEBHOOK_EVENT_TYPES } from '../../types/api'
+import {
+  installComponentGlobals, loadComponent, mountComponent, primitive, translate, unmountComponents
+} from '../../../tests/componentHarness'
+
+const instanceId = '94a904c9-ecbd-49c4-9839-ec4e1eec1ce2'
+const updateInstanceWebhook = vi.fn()
+
+beforeEach(() => {
+  installComponentGlobals()
+  updateInstanceWebhook.mockReset().mockResolvedValue({ id: instanceId })
+  vi.stubGlobal('useToast', () => ({ add: vi.fn() }))
+  vi.stubGlobal('useInstances', () => ({ updateInstanceWebhook }))
+})
+
+afterEach(() => {
+  unmountComponents()
+  vi.unstubAllGlobals()
+})
+
+async function webhookCard() {
+  const component = Object.assign(loadComponent('components/instances/WebhookCard.vue', {
+    'zod': z,
+    '~/types/api': { WEBHOOK_EVENT_TYPES }
+  }), { components: Object.fromEntries(['UForm', 'UCheckbox', 'USwitch'].map(name => [name, primitive(name)])) })
+  return await mountComponent(component, {
+    instance: { id: instanceId, integration: { webhook: { url: 'https://hooks.example.com/wzap', enabled: true, events: ['message'] } } }
+  })
+}
+
+type Card = Awaited<ReturnType<typeof webhookCard>>
+
+async function save(card: Card) {
+  const form = card.findAll('UForm')[0]!
+  const schema = form.props.schema as z.ZodType
+  await card.trigger(form, 'onSubmit', { data: schema.parse(form.props.state) })
+}
+
+async function changeSubscription(card: Card, type: string, value: boolean | 'indeterminate') {
+  const checkbox = card.findAll('UCheckbox').find(entry => entry.props.label === type)!
+  await card.trigger(checkbox, 'onUpdate:modelValue', value)
+}
+
+describe('webhook subscriptions', () => {
+  it('saves independent event changes in contract order without selecting message', async () => {
+    const card = await webhookCard()
+    await card.trigger(card.button(translate('instances.webhook.selectNone')), 'onClick')
+    await changeSubscription(card, 'group.info', true)
+    await changeSubscription(card, 'receipt', true)
+    await save(card)
+    expect(updateInstanceWebhook).toHaveBeenCalledExactlyOnceWith(instanceId, {
+      url: 'https://hooks.example.com/wzap', enabled: true, events: ['receipt', 'group.info']
+    })
+  })
+
+  it('keeps All, removal and None payloads deterministic', async () => {
+    const card = await webhookCard()
+    await card.trigger(card.button(translate('instances.webhook.selectAll')), 'onClick')
+    await changeSubscription(card, 'receipt', 'indeterminate')
+    await save(card)
+    expect(updateInstanceWebhook).toHaveBeenLastCalledWith(instanceId, {
+      url: 'https://hooks.example.com/wzap', enabled: true,
+      events: WEBHOOK_EVENT_TYPES.filter(type => type !== 'receipt')
+    })
+    await card.trigger(card.button(translate('instances.webhook.selectNone')), 'onClick')
+    await card.trigger(card.findAll('USwitch')[0]!, 'onUpdate:modelValue', false)
+    await card.trigger(card.findAll('UInput')[0]!, 'onUpdate:modelValue', '')
+    await save(card)
+    expect(updateInstanceWebhook).toHaveBeenLastCalledWith(instanceId, { url: '', enabled: false, events: [] })
+  })
+})
--- a/manager/app/components/instances/WebhookCard.vue
+++ b/manager/app/components/instances/WebhookCard.vue
@@ -16,16 +16,17 @@
 }>()
 
 const emit = defineEmits<{
   updated: [instance: Instance]
 }>()
 
 const { t } = useI18n()
 const toast = useToast()
+const eventCheckboxId = useId()
 const { updateInstanceWebhook } = useInstances()
 
 const schema = z.object({
   url: z.string().max(2048),
   enabled: z.boolean(),
   events: z.array(z.string())
 }).refine(data => !data.enabled || /^https?:\/\//.test(data.url), {
   message: t('instances.webhook.urlRequired'),
@@ -149,16 +150,17 @@
             </div>
           </div>
           <p class="text-sm text-muted">
             {{ t('instances.webhook.eventsHint') }}
           </p>
           <div class="flex flex-col gap-2">
             <UCheckbox
               v-for="type in WEBHOOK_EVENT_TYPES"
+              :id="`${eventCheckboxId}-${type}`"
               :key="type"
               :model-value="isSubscribed(type)"
               :label="type"
               @update:model-value="(value: boolean | 'indeterminate') => setSubscribed(type, value === true)"
             />
           </div>
           <UAlert
             v-if="subscribedCount === 0"
--- a/manager/app/components/instances/detail/InstanceSectionNav.test.ts
+++ b/manager/app/components/instances/detail/InstanceSectionNav.test.ts
@@ -0,0 +1,76 @@
+import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
+import {
+  flushComponent, installComponentGlobals, loadComponent, mountComponent, primitive, unmountComponents
+} from '../../../../tests/componentHarness'
+
+beforeEach(installComponentGlobals)
+
+afterEach(() => {
+  unmountComponents()
+  vi.unstubAllGlobals()
+})
+
+async function sectionNav(section = 'overview') {
+  const selections: string[] = []
+  const component = Object.assign(loadComponent('components/instances/detail/InstanceSectionNav.vue'), {
+    components: {
+      UDashboardToolbar: primitive('UDashboardToolbar'),
+      UNavigationMenu: primitive('UNavigationMenu')
+    }
+  })
+  const view = await mountComponent(component, { section, onSelect: (value: string) => selections.push(value) })
+  return { ...view, selections }
+}
+
+type SectionChoice = { value: string, label: string, active?: boolean, onSelect?: () => void }
+
+describe('instance section navigation', () => {
+  it('lets the mobile selector emit each of the seven sections once', async () => {
+    const nav = await sectionNav()
+    const selector = nav.findAll('USelect')[0]
+    expect(selector).toBeDefined()
+    const choices = selector!.props.items as SectionChoice[]
+    expect(choices.map(({ value, label }) => ({ value, label }))).toEqual([
+      { value: 'overview', label: 'Overview' },
+      { value: 'messages', label: 'Messages' },
+      { value: 'groups', label: 'Groups' },
+      { value: 'channels', label: 'Channels' },
+      { value: 'profile', label: 'Profile' },
+      { value: 'integrations', label: 'Integrations' },
+      { value: 'settings', label: 'Settings' }
+    ])
+    for (const choice of choices) {
+      await nav.trigger(selector!, 'onUpdate:modelValue', choice.value)
+    }
+    expect(nav.selections).toEqual(['overview', 'messages', 'groups', 'channels', 'profile', 'integrations', 'settings'])
+  })
+
+  it('tracks externally changed current sections in both mobile and desktop controls', async () => {
+    const nav = await sectionNav('integrations')
+    expect(nav.findAll('USelect')[0]).toBeDefined()
+    for (const current of ['integrations', 'settings', 'overview'] as const) {
+      nav.props.section = current
+      await flushComponent()
+      const selector = nav.findAll('USelect')[0]!
+      expect(selector.props.modelValue).toBe(current)
+      const choices = selector.props.items as SectionChoice[]
+      expect(choices.find(choice => choice.value === selector.props.modelValue)?.label).toBe({
+        integrations: 'Integrations', settings: 'Settings', overview: 'Overview'
+      }[current])
+      const menu = nav.findAll('UNavigationMenu')[0]!
+      expect(menu.props.modelValue).toBe(current)
+      expect((menu.props.items as SectionChoice[]).filter(choice => choice.active).map(choice => choice.value)).toEqual([current])
+    }
+    expect(nav.selections).toEqual([])
+  })
+
+  it('keeps desktop selection callbacks connected to the same section event', async () => {
+    const nav = await sectionNav()
+    const menu = nav.findAll('UNavigationMenu')[0]!
+    const choices = menu.props.items as SectionChoice[]
+    choices.find(choice => choice.value === 'integrations')!.onSelect!()
+    choices.find(choice => choice.value === 'settings')!.onSelect!()
+    await flushComponent()
+    expect(nav.selections).toEqual(['integrations', 'settings'])
+  })
+})
--- a/manager/app/components/instances/detail/InstanceSectionNav.vue
+++ b/manager/app/components/instances/detail/InstanceSectionNav.vue
@@ -1,34 +1,45 @@
 <script setup lang="ts">
 import type { NavigationMenuItem } from '#ui/types'
 
 const { t } = useI18n()
 const props = defineProps<{ section: string }>()
 const emit = defineEmits<{ select: [value: string] }>()
 
-// Section nav mirrors research/dashboard settings.vue: UNavigationMenu in a
-// UDashboardToolbar with icons + highlight. Switching still rides on each
-// item's onSelect (UNavigationMenu does not reliably emit update:modelValue
-// for value-only items), while `active` + `model-value` keep the highlight
-// pill in sync with the local section state instead of the route.
-const items = computed<NavigationMenuItem[]>(() => [
-  { label: t('instances.sections.overview'), icon: 'i-lucide-house', value: 'overview', active: props.section === 'overview', onSelect: () => emit('select', 'overview') },
-  { label: t('instances.sections.messages'), icon: 'i-lucide-message-square-text', value: 'messages', active: props.section === 'messages', onSelect: () => emit('select', 'messages') },
-  { label: t('instances.sections.groups'), icon: 'i-lucide-users', value: 'groups', active: props.section === 'groups', onSelect: () => emit('select', 'groups') },
-  { label: t('instances.sections.channels'), icon: 'i-lucide-megaphone', value: 'channels', active: props.section === 'channels', onSelect: () => emit('select', 'channels') },
-  { label: t('instances.sections.profile'), icon: 'i-lucide-user', value: 'profile', active: props.section === 'profile', onSelect: () => emit('select', 'profile') },
-  { label: t('instances.sections.integrations'), icon: 'i-lucide-plug', value: 'integrations', active: props.section === 'integrations', onSelect: () => emit('select', 'integrations') },
-  { label: t('instances.sections.settings'), icon: 'i-lucide-settings', value: 'settings', active: props.section === 'settings', onSelect: () => emit('select', 'settings') }
+const sections = computed(() => [
+  { label: t('instances.sections.overview'), icon: 'i-lucide-house', value: 'overview' },
+  { label: t('instances.sections.messages'), icon: 'i-lucide-message-square-text', value: 'messages' },
+  { label: t('instances.sections.groups'), icon: 'i-lucide-users', value: 'groups' },
+  { label: t('instances.sections.channels'), icon: 'i-lucide-megaphone', value: 'channels' },
+  { label: t('instances.sections.profile'), icon: 'i-lucide-user', value: 'profile' },
+  { label: t('instances.sections.integrations'), icon: 'i-lucide-plug', value: 'integrations' },
+  { label: t('instances.sections.settings'), icon: 'i-lucide-settings', value: 'settings' }
 ])
+
+// NavigationMenu value-only items need onSelect; the mobile select uses its
+// model update instead so choosing one section emits only once.
+const items = computed<NavigationMenuItem[]>(() => sections.value.map(item => ({
+  ...item,
+  active: props.section === item.value,
+  onSelect: () => emit('select', item.value)
+})))
 </script>
 
 <template>
   <UDashboardToolbar>
+    <USelect
+      :model-value="section"
+      :items="sections"
+      :aria-label="t('instances.sections.label')"
+      size="lg"
+      class="min-h-11 w-full min-w-0 lg:hidden"
+      @update:model-value="value => emit('select', value)"
+    />
     <!-- NOTE: The `-mx-1` class is used to align with the `DashboardSidebarCollapse` button here. -->
     <UNavigationMenu
       :model-value="section"
       highlight
-      class="-mx-1 max-w-full min-w-0 flex-1 overflow-x-auto"
+      class="-mx-1 hidden max-w-full min-w-0 flex-1 overflow-x-auto lg:flex"
       :items="items"
     />
   </UDashboardToolbar>
 </template>
--- a/manager/app/components/instances/detail/InstanceSettingsSection.vue
+++ b/manager/app/components/instances/detail/InstanceSettingsSection.vue
@@ -183,16 +183,17 @@
             v-if="disappearingFailure"
             color="error"
             variant="subtle"
             :title="disappearingFailure"
           />
           <div class="flex flex-wrap items-end gap-2">
             <USelect
               v-model="disappearingChoice"
+              :aria-label="t('instances.settings.defaultDisappearing')"
               :items="disappearingOptions"
               class="min-w-48"
             />
             <UButton
               :loading="savingDisappearing"
               :label="t('instances.settings.saveDefaultDisappearing')"
               @click="onSaveDefaultDisappearing"
             />
--- a/manager/app/components/shared/DataTableToolbar.vue
+++ b/manager/app/components/shared/DataTableToolbar.vue
@@ -34,16 +34,17 @@
       :aria-label="searchAria"
       class="max-w-sm"
     />
 
     <div class="flex flex-wrap items-center gap-1.5">
       <slot name="bulk" />
       <slot name="filters" />
       <UDropdownMenu
+        v-if="columnItems.length > 0"
         :items="[columnItems]"
         :content="{ align: 'end' }"
       >
         <UButton
           :label="displayLabel"
           color="neutral"
           variant="outline"
           trailing-icon="i-lucide-settings-2"
--- a/manager/app/components/shared/FileUploadPreview.vue
+++ b/manager/app/components/shared/FileUploadPreview.vue
@@ -0,0 +1,20 @@
+<script setup lang="ts">
+import { useObjectUrl } from '@vueuse/core'
+
+const props = defineProps<{
+  file: File
+}>()
+const appConfig = useAppConfig()
+const previewUrl = useObjectUrl(() => props.file)
+</script>
+
+<template>
+  <!-- Grid previews hide the filename, so the image identifies the selected file. -->
+  <UAvatar
+    :as="{ img: 'img' }"
+    :src="previewUrl"
+    :alt="file.name"
+    :icon="appConfig.ui.icons.file"
+    data-slot="fileLeadingAvatar"
+  />
+</template>
--- a/manager/app/pages/instances/[id].vue
+++ b/manager/app/pages/instances/[id].vue
@@ -120,16 +120,17 @@
     <template #header>
       <UDashboardNavbar :title="instance?.name ?? t('instances.title')">
         <template #leading>
           <UDashboardSidebarCollapse />
           <UButton
             color="neutral"
             variant="ghost"
             icon="i-lucide-arrow-left"
+            :aria-label="t('instances.detail.back')"
             @click="navigateTo('/instances')"
           />
         </template>
         <template v-if="instance" #right>
           <InstanceStatusBadge :status="instance.connection.status" />
         </template>
       </UDashboardNavbar>
 
--- a/manager/app/utils/accountQuota.test.ts
+++ b/manager/app/utils/accountQuota.test.ts
@@ -0,0 +1,21 @@
+import { describe, expect, it } from 'vitest'
+import { parseQuota } from './accountQuota'
+
+describe('quota input parsing', () => {
+  it.each([
+    [undefined, undefined],
+    ['', undefined],
+    ['   ', undefined],
+    [0, 0],
+    ['0', 0],
+    [2, 2],
+    ['2', 2],
+    [' 3 ', 3]
+  ])('normalizes %j to %j while keeping the default distinct from unlimited', (input, expected) => {
+    expect(parseQuota(input)).toBe(expected)
+  })
+
+  it.each([-1, '-1', 1.5, '1.5', NaN, 'NaN', Infinity, 'Infinity', -Infinity, 'quota'])('rejects %j', (input) => {
+    expect(parseQuota(input)).toBeNull()
+  })
+})
--- a/manager/app/utils/accountQuota.ts
+++ b/manager/app/utils/accountQuota.ts
@@ -1,13 +1,13 @@
 // Empty stays omitted so the server default applies; 0 is a valid explicit
 // value meaning unlimited.
-export function parseQuota(raw: string): number | undefined | null {
-  const trimmed = raw.trim()
-  if (trimmed === '') {
+export function parseQuota(raw: string | number | undefined): number | undefined | null {
+  const value = typeof raw === 'string' ? raw.trim() : raw
+  if (value === undefined || value === '') {
     return undefined
   }
-  const parsed = Number(trimmed)
+  const parsed = Number(value)
   if (!Number.isInteger(parsed) || parsed < 0) {
     return null
   }
   return parsed
 }
--- a/manager/app/utils/tableRowNavigation.test.ts
+++ b/manager/app/utils/tableRowNavigation.test.ts
@@ -0,0 +1,73 @@
+import { describe, expect, it } from 'vitest'
+import { tableRowNavigation } from './tableRowNavigation'
+
+// Only native DOM lookup boundaries are supplied: the resolver itself chooses
+// whether and which displayed row can navigate. Browser QA checks selectors.
+function tableFixture() {
+  const body = { rows: [] as object[] }
+  const first = { parentElement: body }
+  const second = { parentElement: body }
+  body.rows = [first, second]
+  const table = { tBodies: [body] } as unknown as HTMLTableElement
+
+  function click(row: object | null, options: {
+    interactive?: boolean
+    owner?: HTMLTableElement
+    defaultPrevented?: boolean
+    button?: number
+  } = {}): MouseEvent {
+    return {
+      button: options.button ?? 0,
+      defaultPrevented: options.defaultPrevented ?? false,
+      target: {
+        closest: (selector: string) => {
+          if (selector === 'tr') return row
+          if (selector === 'table') return options.owner ?? table
+          return options.interactive ? {} : null
+        }
+      }
+    } as unknown as MouseEvent
+  }
+
+  return { table, body, first, second, click }
+}
+
+describe('table row pointer navigation', () => {
+  it('resolves the clicked row against the displayed order after sorting', () => {
+    const { table, second, click } = tableFixture()
+    expect(tableRowNavigation(click(second), table, [{ id: 'zulu' }, { id: 'alpha' }])).toEqual({ id: 'alpha' })
+  })
+
+  it('uses the current filtered page rather than an index into all instances', () => {
+    const { table, first, click } = tableFixture()
+    expect(tableRowNavigation(click(first), table, [{ id: 'page-two-filtered-match' }])).toEqual({ id: 'page-two-filtered-match' })
+  })
+
+  it('leaves interactive descendants to their own controls', () => {
+    const { table, first, click } = tableFixture()
+    expect(tableRowNavigation(click(first, { interactive: true }), table, [{ id: 'alpha' }])).toBeUndefined()
+  })
+
+  it('ignores header rows and elements outside rows', () => {
+    const { table, click } = tableFixture()
+    expect(tableRowNavigation(click({ parentElement: {} }), table, [{ id: 'alpha' }])).toBeUndefined()
+    expect(tableRowNavigation(click(null), table, [{ id: 'alpha' }])).toBeUndefined()
+  })
+
+  it('does not resolve an empty-state body row to an instance', () => {
+    const { table, first, click } = tableFixture()
+    expect(tableRowNavigation(click(first), table, [])).toBeUndefined()
+  })
+
+  it('rejects nested or foreign tables even when the event reaches the root', () => {
+    const { table, first, click } = tableFixture()
+    const foreignTable = {} as HTMLTableElement
+    expect(tableRowNavigation(click(first, { owner: foreignTable }), table, [{ id: 'alpha' }])).toBeUndefined()
+  })
+
+  it('ignores prevented and non-primary clicks', () => {
+    const { table, first, click } = tableFixture()
+    expect(tableRowNavigation(click(first, { defaultPrevented: true }), table, [{ id: 'alpha' }])).toBeUndefined()
+    expect(tableRowNavigation(click(first, { button: 1 }), table, [{ id: 'alpha' }])).toBeUndefined()
+  })
+})
--- a/manager/app/utils/tableRowNavigation.ts
+++ b/manager/app/utils/tableRowNavigation.ts
@@ -0,0 +1,17 @@
+// Resolve pointer navigation separately from the table's native controls.
+export function tableRowNavigation<T>(
+  event: MouseEvent,
+  table: HTMLTableElement | null | undefined,
+  displayedRows: readonly T[]
+): T | undefined {
+  if (!table || event.defaultPrevented || event.button !== 0) return
+
+  const target = event.target as Element | null
+  if (!target?.closest || target.closest('a, button, input, select, textarea, label, [role="checkbox"], [role="menuitem"], [role="menuitemcheckbox"], [contenteditable="true"]')) return
+
+  const row = target.closest('tr')
+  const body = table.tBodies[0]
+  if (!row || !body || row.parentElement !== body || target.closest('table') !== table) return
+
+  return displayedRows[Array.from(body.rows).indexOf(row)]
+}
--- a/manager/i18n/locales/en.json
+++ b/manager/i18n/locales/en.json
@@ -12,16 +12,19 @@
     "noNotifications": "No notifications yet.",
     "searchPlaceholder": "Search actions and pages..."
   },
   "auth": {
     "loginTitle": "Sign in to wzap",
     "loginSubtitle": "Use your manager account to continue.",
     "email": "Email",
     "password": "Password",
+    "emailRequired": "Enter your email.",
+    "emailInvalid": "Enter a valid email address.",
+    "passwordRequired": "Enter your password.",
     "submit": "Sign in",
     "signingIn": "Signing in...",
     "loginFailed": "Sign in failed. Check your email and password.",
     "serviceUnavailable": "Could not reach the service. Check your connection and try again.",
     "sessionExpired": "Your session expired. Sign in again."
   },
   "userMenu": {
     "account": "Account",
@@ -179,16 +182,17 @@
       "failed": "Could not create the instance.",
       "quotaExceeded": "Instance quota exceeded. Nothing was created.",
       "externalRefTaken": "This external reference is already in use.",
       "successTitle": "Instance created",
       "successBody": "Copy the API key now. It will never be shown again.",
       "createdToast": "Instance created as disconnected."
     },
     "detail": {
+      "back": "Back to instances",
       "loadFailed": "Could not load the instance.",
       "notFound": "Instance not found.",
       "saved": "Instance updated.",
       "saveFailed": "Could not save the instance.",
       "externalRefTaken": "This external reference is already in use.",
       "disconnect": "Disconnect",
       "disconnecting": "Disconnecting...",
       "disconnectConfirmTitle": "Disconnect instance",
@@ -337,16 +341,17 @@
       "type": "Type",
       "lastError": "Last error",
       "attempts": "Attempts",
       "createdAt": "Created",
       "deliveredAt": "Delivered",
       "readAt": "Read"
     },
     "sections": {
+      "label": "Instance section",
       "overview": "Overview",
       "messages": "Messages",
       "groups": "Groups",
       "channels": "Channels",
       "profile": "Profile",
       "integrations": "Integrations",
       "settings": "Settings"
     },
--- a/manager/tests/componentHarness.ts
+++ b/manager/tests/componentHarness.ts
@@ -71,16 +71,17 @@
   const javascript = compiledSource(filename, (source) => {
     const descriptor = compiler.parse(source, { filename }).descriptor
     const compiled = compiler.compileScript(descriptor, { id: relativePath, inlineTemplate: true })
     return transpile(compiled.content)
   })
   const module = evaluate(javascript, {
     'vue': Vue,
     '~/composables/useApi': { ApiError },
+    '~/components/shared/FileUploadPreview.vue': { default: primitive('FileUploadPreview') },
     ...imports
   }) as { default: Vue.Component }
   return module.default
 }
 
 export function loadScript(relativePath: string, imports: Record<string, unknown>): Record<string, unknown> {
   const filename = fileURLToPath(new URL(`../app/${relativePath}`, import.meta.url))
   return evaluate(compiledSource(filename, transpile), imports) as Record<string, unknown>
@@ -136,17 +137,23 @@
 export function primitive(name: string): Vue.Component {
   return Vue.defineComponent({
     name,
     inheritAttrs: false,
     props: ['modelValue'],
     setup(props, { attrs, slots }) {
       return () => Vue.h(name, { ...attrs, modelValue: props.modelValue }, [
         typeof attrs.label === 'string' ? attrs.label : '',
-        ...Object.values(slots).flatMap(slot => slot?.({}) ?? [])
+        ...Object.entries(slots).flatMap(([slotName, slot]) => {
+          if (name === 'UFileUpload' && slotName === 'file-leading') {
+            const files = Array.isArray(props.modelValue) ? props.modelValue : props.modelValue ? [props.modelValue] : []
+            return files.flatMap((file, index) => slot?.({ file, index, ui: { fileLeadingAvatar: () => '' } }) ?? [])
+          }
+          return slot?.({}) ?? []
+        })
       ])
     }
   })
 }
 
 const primitiveNames = [
   'UPageCard', 'UCard', 'UAlert', 'UFormField', 'UInput', 'UTextarea',
   'UFileUpload', 'UButton', 'UTabs', 'USelect', 'UAvatar', 'UEmpty',
```
